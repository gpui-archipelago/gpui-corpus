// Modified by Longbridge for gpui-fast.
use crate::{
    ActivityGuard, AnyWindowHandle, AppLifecyclePhase, BackgroundExecutor, ClipboardItem,
    CursorStyle, DevicePixels, DummyKeyboardMapper, ForegroundExecutor, Keymap, OwnedMenu,
    Platform, PlatformDisplay, PlatformHeadlessRenderer, PlatformKeyboardLayout,
    PlatformKeyboardMapper, PlatformTextSystem, PromptButton, ScreenCaptureFrame,
    ScreenCaptureSource, ScreenCaptureStream, SharedString, SourceMetadata, SystemNotification,
    SystemNotificationResponse, Task, TestDisplay, TestWindow, ThermalState, WindowAppearance,
    WindowParams, size,
};
#[cfg(any(test, feature = "test-support"))]
use crate::{DisplayId, NoopTextSystem, PathPromptOptions};
use anyhow::Result;
#[cfg(any(test, feature = "test-support"))]
use collections::VecDeque;
use futures::channel::oneshot;
use parking_lot::Mutex;
use std::{
    cell::{Cell, RefCell},
    path::{Path, PathBuf},
    rc::{Rc, Weak},
    sync::{
        Arc,
        atomic::{AtomicUsize, Ordering},
    },
    time::Duration,
};

/// TestPlatform implements the Platform trait for use in tests.
pub(crate) struct TestPlatform {
    pub(crate) platform_info: Cell<crate::PlatformInfo>,
    background_executor: BackgroundExecutor,
    foreground_executor: ForegroundExecutor,

    pub(crate) active_window: RefCell<Option<TestWindow>>,
    displays: RefCell<Vec<TestDisplay>>,
    displays_changed_callback: RefCell<Option<Box<dyn FnMut()>>>,
    pub(crate) active_cursor: Mutex<CursorStyle>,
    current_clipboard_item: Mutex<Option<ClipboardItem>>,
    #[cfg(any(target_os = "linux", target_os = "freebsd"))]
    current_primary_item: Mutex<Option<ClipboardItem>>,
    #[cfg(target_os = "macos")]
    current_find_pasteboard_item: Mutex<Option<ClipboardItem>>,
    #[cfg(any(test, feature = "test-support"))]
    pub(crate) prompts: RefCell<TestPrompts>,
    screen_capture_sources: RefCell<Vec<TestScreenCaptureSource>>,
    pub opened_url: RefCell<Option<String>>,
    pub(crate) system_notifications: RefCell<TestSystemNotifications>,
    pub text_system: Arc<dyn PlatformTextSystem>,
    pub expect_restart:
        RefCell<Option<oneshot::Sender<(Option<PathBuf>, Vec<std::ffi::OsString>)>>>,
    idle_sleep_prevention_count: Arc<AtomicUsize>,
    idle_sleep_prevention_delay: Cell<Duration>,
    idle_sleep_prevention_fails: Cell<bool>,
    headless_renderer_factory:
        Option<Box<dyn Fn() -> anyhow::Result<Option<Box<dyn PlatformHeadlessRenderer>>>>>,
    weak: Weak<Self>,
    menus: RefCell<Vec<OwnedMenu>>,
    pub(crate) app_lifecycle_callback: RefCell<Option<Box<dyn FnMut(AppLifecyclePhase)>>>,
    pub(crate) memory_warning_callback: RefCell<Option<Box<dyn FnMut()>>>,
}

#[derive(Clone)]
/// A fake screen capture source, used for testing.
pub struct TestScreenCaptureSource {}

/// A fake screen capture stream, used for testing.
pub struct TestScreenCaptureStream {}

impl ScreenCaptureSource for TestScreenCaptureSource {
    fn metadata(&self) -> Result<SourceMetadata> {
        Ok(SourceMetadata {
            id: 0,
            is_main: None,
            label: None,
            resolution: size(DevicePixels(1), DevicePixels(1)),
        })
    }

    fn stream(
        &self,
        _foreground_executor: &ForegroundExecutor,
        _frame_callback: Box<dyn Fn(ScreenCaptureFrame) + Send>,
    ) -> oneshot::Receiver<Result<Box<dyn ScreenCaptureStream>>> {
        let (tx, rx) = oneshot::channel();
        let stream = TestScreenCaptureStream {};
        tx.send(Ok(Box::new(stream) as Box<dyn ScreenCaptureStream>))
            .ok();
        rx
    }
}

impl ScreenCaptureStream for TestScreenCaptureStream {
    fn metadata(&self) -> Result<SourceMetadata> {
        TestScreenCaptureSource {}.metadata()
    }
}

#[cfg(any(test, feature = "test-support"))]
struct TestPrompt {
    msg: String,
    detail: Option<String>,
    answers: Vec<String>,
    tx: oneshot::Sender<usize>,
}

#[derive(Default)]
pub(crate) struct TestSystemNotifications {
    pub(crate) app_identity: Option<(SharedString, SharedString)>,
    pub(crate) shown: Vec<SystemNotification>,
    pub(crate) delivered: Vec<SystemNotification>,
    pub(crate) dismissed: Vec<SharedString>,
    response_callback: Option<Box<dyn FnMut(SystemNotificationResponse)>>,
}

#[cfg(any(test, feature = "test-support"))]
#[derive(Default)]
pub(crate) struct TestPrompts {
    multiple_choice: VecDeque<TestPrompt>,
    new_path: VecDeque<(PathBuf, oneshot::Sender<Result<Option<PathBuf>>>)>,
    paths: VecDeque<(
        PathPromptOptions,
        oneshot::Sender<Result<Option<Vec<PathBuf>>>>,
    )>,
}

impl TestPlatform {
    #[cfg(test)]
    pub(crate) fn cursor_style(&self) -> CursorStyle {
        *self.active_cursor.lock()
    }

    #[cfg(any(test, feature = "test-support"))]
    pub fn new(executor: BackgroundExecutor, foreground_executor: ForegroundExecutor) -> Rc<Self> {
        Self::with_platform(
            executor,
            foreground_executor,
            Arc::new(NoopTextSystem),
            None,
        )
    }

    #[cfg(any(test, feature = "test-support"))]
    pub fn with_text_system(
        executor: BackgroundExecutor,
        foreground_executor: ForegroundExecutor,
        text_system: Arc<dyn PlatformTextSystem>,
    ) -> Rc<Self> {
        Self::with_platform(executor, foreground_executor, text_system, None)
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn simulate_display_added(
        &self,
        display_id: DisplayId,
        refresh_interval: Option<Duration>,
    ) {
        self.connect_display(display_id, refresh_interval);
        self.report_displays_changed();
    }

    /// Adds a display without telling App yet, as when the platform's
    /// notifications about a window arrive before those about displays.
    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn connect_display(
        &self,
        display_id: DisplayId,
        refresh_interval: Option<Duration>,
    ) {
        let mut display = TestDisplay::with_id(display_id);
        display.refresh_interval = refresh_interval;
        self.displays.borrow_mut().push(display);
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn simulate_display_removed(&self, display_id: DisplayId) {
        self.displays
            .borrow_mut()
            .retain(|display| display.id() != display_id);
        self.report_displays_changed();
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn simulate_display_refresh_interval_change(
        &self,
        display_id: DisplayId,
        refresh_interval: Option<Duration>,
    ) {
        for display in self.displays.borrow_mut().iter_mut() {
            if display.id() == display_id {
                display.refresh_interval = refresh_interval;
            }
        }
        self.report_displays_changed();
    }

    #[cfg(any(test, feature = "test-support"))]
    fn report_displays_changed(&self) {
        let callback = self.displays_changed_callback.borrow_mut().take();
        if let Some(mut callback) = callback {
            callback();
            self.displays_changed_callback
                .borrow_mut()
                .get_or_insert(callback);
        }
    }

    pub fn with_platform(
        executor: BackgroundExecutor,
        foreground_executor: ForegroundExecutor,
        text_system: Arc<dyn PlatformTextSystem>,
        headless_renderer_factory: Option<
            Box<dyn Fn() -> anyhow::Result<Option<Box<dyn PlatformHeadlessRenderer>>>>,
        >,
    ) -> Rc<Self> {
        Rc::new_cyclic(|weak| TestPlatform {
            platform_info: Cell::new(crate::PlatformInfo {
                os: std::cfg_select! {
                    target_os = "macos" => { crate::OperatingSystem::Mac }
                    target_os = "windows" => { crate::OperatingSystem::Windows }
                    target_os = "linux" => { crate::OperatingSystem::Linux }
                    target_os = "freebsd" => { crate::OperatingSystem::FreeBsd }
                    target_os = "ios" => { crate::OperatingSystem::Ios }
                    target_os = "android" => { crate::OperatingSystem::Android }
                    target_family = "wasm" => {
                        // Browser tests must supply the host OS with set_platform_info.
                        crate::OperatingSystem::Unknown
                    }
                    _ => { compile_error!("unsupported test platform operating system") }
                },
                target: std::cfg_select! {
                    target_family = "wasm" => { crate::PlatformTarget::Web }
                    any(
                        target_os = "macos",
                        target_os = "windows",
                        target_os = "linux",
                        target_os = "freebsd",
                        target_os = "ios",
                        target_os = "android"
                    ) => { crate::PlatformTarget::Native }
                    _ => { compile_error!("unsupported test platform target") }
                },
            }),
            background_executor: executor,
            foreground_executor,
            #[cfg(any(test, feature = "test-support"))]
            prompts: Default::default(),
            screen_capture_sources: Default::default(),
            active_cursor: Default::default(),
            displays: RefCell::new(vec![TestDisplay::new()]),
            displays_changed_callback: Default::default(),
            active_window: Default::default(),
            expect_restart: Default::default(),
            current_clipboard_item: Mutex::new(None),
            #[cfg(any(target_os = "linux", target_os = "freebsd"))]
            current_primary_item: Mutex::new(None),
            #[cfg(target_os = "macos")]
            current_find_pasteboard_item: Mutex::new(None),
            idle_sleep_prevention_count: Arc::new(AtomicUsize::new(0)),
            idle_sleep_prevention_delay: Cell::new(Duration::ZERO),
            idle_sleep_prevention_fails: Cell::new(false),
            weak: weak.clone(),
            opened_url: Default::default(),
            system_notifications: Default::default(),
            text_system,
            headless_renderer_factory,
            menus: Default::default(),
            app_lifecycle_callback: Default::default(),
            memory_warning_callback: Default::default(),
        })
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn simulate_new_path_selection(
        &self,
        select_path: impl FnOnce(&std::path::Path) -> Option<std::path::PathBuf>,
    ) {
        let (path, tx) = self
            .prompts
            .borrow_mut()
            .new_path
            .pop_front()
            .expect("no pending new path prompt");
        tx.send(Ok(select_path(&path))).ok();
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn simulate_path_prompt_response(
        &self,
        select_paths: impl FnOnce(&PathPromptOptions) -> Option<Vec<std::path::PathBuf>>,
    ) {
        let (options, tx) = self
            .prompts
            .borrow_mut()
            .paths
            .pop_front()
            .expect("no pending paths prompt");
        let selection = select_paths(&options);
        if let Some(paths) = &selection
            && !options.multiple
            && paths.len() > 1
        {
            panic!(
                "selected {} paths for a prompt that does not allow multiple selection",
                paths.len()
            );
        }
        tx.send(Ok(selection)).ok();
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn did_prompt_for_paths(&self) -> bool {
        !self.prompts.borrow().paths.is_empty()
    }

    #[cfg(any(test, feature = "test-support"))]
    #[track_caller]
    pub(crate) fn simulate_prompt_answer(&self, response: &str) {
        let prompt = self
            .prompts
            .borrow_mut()
            .multiple_choice
            .pop_front()
            .expect("no pending multiple choice prompt");
        let Some(ix) = prompt.answers.iter().position(|a| a == response) else {
            panic!(
                "PROMPT: {}\n{:?}\n{:?}\nCannot respond with {}",
                prompt.msg, prompt.detail, prompt.answers, response
            )
        };
        prompt.tx.send(ix).ok();
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn has_pending_prompt(&self) -> bool {
        !self.prompts.borrow().multiple_choice.is_empty()
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn pending_prompt(&self) -> Option<(String, String)> {
        let prompts = self.prompts.borrow();
        let prompt = prompts.multiple_choice.front()?;
        Some((
            prompt.msg.clone(),
            prompt.detail.clone().unwrap_or_default(),
        ))
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn set_screen_capture_sources(&self, sources: Vec<TestScreenCaptureSource>) {
        *self.screen_capture_sources.borrow_mut() = sources;
    }

    /// Queues the prompt so a test can later inspect or answer it through
    /// [`Self::pending_prompt`] and [`Self::simulate_prompt_answer`].
    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn prompt(
        &self,
        msg: &str,
        detail: Option<&str>,
        answers: &[PromptButton],
    ) -> oneshot::Receiver<usize> {
        let (tx, rx) = oneshot::channel();
        let answers: Vec<String> = answers.iter().map(|s| s.label().to_string()).collect();
        self.prompts
            .borrow_mut()
            .multiple_choice
            .push_back(TestPrompt {
                msg: msg.to_string(),
                detail: detail.map(|s| s.to_string()),
                answers,
                tx,
            });
        rx
    }

    /// Benchmarks have no API to answer a prompt, so this doesn't retain it
    /// for later inspection; dropping the sender immediately cancels the
    /// returned receiver instead of leaving it pending indefinitely.
    #[cfg(not(any(test, feature = "test-support")))]
    pub(crate) fn prompt(
        &self,
        _msg: &str,
        _detail: Option<&str>,
        _answers: &[PromptButton],
    ) -> oneshot::Receiver<usize> {
        oneshot::channel().1
    }

    pub(crate) fn set_active_window(&self, window: Option<TestWindow>) {
        let executor = self.foreground_executor();
        let previous_window = self.active_window.borrow_mut().take();
        self.active_window.borrow_mut().clone_from(&window);

        executor
            .spawn(async move {
                if let Some(previous_window) = previous_window {
                    if let Some(window) = window.as_ref()
                        && Rc::ptr_eq(&previous_window.0, &window.0)
                    {
                        return;
                    }
                    previous_window.simulate_active_status_change(false);
                }
                if let Some(window) = window {
                    window.simulate_active_status_change(true);
                }
            })
            .detach();
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn did_prompt_for_new_path(&self) -> bool {
        !self.prompts.borrow().new_path.is_empty()
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn active_idle_sleep_preventions(&self) -> usize {
        self.idle_sleep_prevention_count.load(Ordering::SeqCst)
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn set_idle_sleep_prevention_delay(&self, delay: Duration) {
        self.idle_sleep_prevention_delay.set(delay);
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn set_idle_sleep_prevention_fails(&self, fails: bool) {
        self.idle_sleep_prevention_fails.set(fails);
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn app_identity(&self) -> Option<(SharedString, SharedString)> {
        self.system_notifications.borrow().app_identity.clone()
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn shown_system_notifications(&self) -> Vec<SystemNotification> {
        self.system_notifications.borrow().shown.clone()
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn delivered_system_notifications(&self) -> Vec<SystemNotification> {
        self.system_notifications.borrow().delivered.clone()
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn dismissed_system_notifications(&self) -> Vec<SharedString> {
        self.system_notifications.borrow().dismissed.clone()
    }

    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn simulate_system_notification_response(
        &self,
        response: SystemNotificationResponse,
    ) {
        let callback = self
            .system_notifications
            .borrow_mut()
            .response_callback
            .take();
        if let Some(mut callback) = callback {
            callback(response);
            self.system_notifications
                .borrow_mut()
                .response_callback
                .get_or_insert(callback);
        }
    }
}

impl Platform for TestPlatform {
    fn platform_info(&self) -> crate::PlatformInfo {
        self.platform_info.get()
    }

    fn background_executor(&self) -> BackgroundExecutor {
        self.background_executor.clone()
    }

    fn foreground_executor(&self) -> ForegroundExecutor {
        self.foreground_executor.clone()
    }

    fn text_system(&self) -> Arc<dyn PlatformTextSystem> {
        self.text_system.clone()
    }

    fn keyboard_layout(&self) -> Box<dyn PlatformKeyboardLayout> {
        Box::new(TestKeyboardLayout)
    }

    fn keyboard_mapper(&self) -> Rc<dyn PlatformKeyboardMapper> {
        Rc::new(DummyKeyboardMapper)
    }

    fn on_keyboard_layout_change(&self, _: Box<dyn FnMut()>) {}

    fn on_thermal_state_change(&self, _: Box<dyn FnMut()>) {}

    fn thermal_state(&self) -> ThermalState {
        ThermalState::Nominal
    }

    fn prevent_idle_sleep(&self, reason: &str) -> Task<Result<ActivityGuard>> {
        let count = self.idle_sleep_prevention_count.clone();
        let fails = self.idle_sleep_prevention_fails.get();
        let reason = reason.to_owned();
        let acquire = move || {
            if fails {
                anyhow::bail!("Idle sleep prevention for {reason:?} is set to fail in this test");
            }
            count.fetch_add(1, Ordering::SeqCst);
            Ok(ActivityGuard::new(move || {
                count.fetch_sub(1, Ordering::SeqCst);
            }))
        };

        let delay = self.idle_sleep_prevention_delay.get();
        if delay.is_zero() {
            Task::ready(acquire())
        } else {
            let delay = self.background_executor.timer(delay);
            self.foreground_executor.spawn(async move {
                delay.await;
                acquire()
            })
        }
    }

    fn run(&self, _on_finish_launching: Box<dyn FnOnce()>) {
        unimplemented!()
    }

    fn quit(&self) {}

    fn restart(&self, path: Option<PathBuf>, arguments: Vec<std::ffi::OsString>) {
        if let Some(tx) = self.expect_restart.take() {
            tx.send((path, arguments)).unwrap();
        }
    }

    fn activate(&self, _ignoring_other_apps: bool) {
        //
    }

    fn hide(&self) {
        unimplemented!()
    }

    fn hide_other_apps(&self) {
        unimplemented!()
    }

    fn unhide_other_apps(&self) {
        unimplemented!()
    }

    fn displays(&self) -> Vec<std::rc::Rc<dyn crate::PlatformDisplay>> {
        self.displays
            .borrow()
            .iter()
            .map(|display| Rc::new(display.clone()) as Rc<dyn PlatformDisplay>)
            .collect()
    }

    fn primary_display(&self) -> Option<std::rc::Rc<dyn crate::PlatformDisplay>> {
        self.displays
            .borrow()
            .first()
            .map(|display| Rc::new(display.clone()) as Rc<dyn PlatformDisplay>)
    }

    fn on_displays_changed(&self, callback: Box<dyn FnMut()>) {
        *self.displays_changed_callback.borrow_mut() = Some(callback);
    }

    fn is_screen_capture_supported(&self) -> bool {
        true
    }

    fn screen_capture_sources(
        &self,
    ) -> oneshot::Receiver<Result<Vec<Rc<dyn ScreenCaptureSource>>>> {
        let (tx, rx) = oneshot::channel();
        tx.send(Ok(self
            .screen_capture_sources
            .borrow()
            .iter()
            .map(|source| Rc::new(source.clone()) as Rc<dyn ScreenCaptureSource>)
            .collect()))
            .ok();
        rx
    }

    fn active_window(&self) -> Option<crate::AnyWindowHandle> {
        self.active_window
            .borrow()
            .as_ref()
            .map(|window| window.0.lock().handle)
    }

    fn open_window(
        &self,
        handle: AnyWindowHandle,
        params: WindowParams,
    ) -> anyhow::Result<Box<dyn crate::PlatformWindow>> {
        let renderer = match self.headless_renderer_factory.as_ref() {
            Some(factory) => factory()?,
            None => None,
        };
        let window = TestWindow::new(
            handle,
            params,
            self.weak.clone(),
            self.primary_display()
                .unwrap_or_else(|| Rc::new(TestDisplay::new())),
            renderer,
        );
        Ok(Box::new(window))
    }

    fn window_appearance(&self) -> WindowAppearance {
        WindowAppearance::Light
    }

    fn open_url(&self, url: &str) {
        *self.opened_url.borrow_mut() = Some(url.to_string())
    }

    fn on_open_urls(&self, _callback: Box<dyn FnMut(Vec<String>)>) {
        unimplemented!()
    }

    /// Queues the prompt so a test can later answer it through
    /// [`Self::simulate_path_prompt_response`].
    #[cfg(any(test, feature = "test-support"))]
    fn prompt_for_paths(
        &self,
        options: crate::PathPromptOptions,
    ) -> oneshot::Receiver<Result<Option<Vec<std::path::PathBuf>>>> {
        let (tx, rx) = oneshot::channel();
        self.prompts.borrow_mut().paths.push_back((options, tx));
        rx
    }

    /// Benchmarks have no API to answer a path prompt, so this doesn't
    /// retain it for later inspection; dropping the sender immediately
    /// cancels the returned receiver instead of leaving it pending
    /// indefinitely.
    #[cfg(not(any(test, feature = "test-support")))]
    fn prompt_for_paths(
        &self,
        _options: crate::PathPromptOptions,
    ) -> oneshot::Receiver<Result<Option<Vec<std::path::PathBuf>>>> {
        oneshot::channel().1
    }

    /// Queues the prompt so a test can later answer it through
    /// [`Self::simulate_new_path_selection`].
    #[cfg(any(test, feature = "test-support"))]
    fn prompt_for_new_path(
        &self,
        directory: &std::path::Path,
        _suggested_name: Option<&str>,
    ) -> oneshot::Receiver<Result<Option<std::path::PathBuf>>> {
        let (tx, rx) = oneshot::channel();
        self.prompts
            .borrow_mut()
            .new_path
            .push_back((directory.to_path_buf(), tx));
        rx
    }

    /// Benchmarks have no API to answer a new-path prompt, so this doesn't
    /// retain it for later inspection; dropping the sender immediately
    /// cancels the returned receiver instead of leaving it pending
    /// indefinitely.
    #[cfg(not(any(test, feature = "test-support")))]
    fn prompt_for_new_path(
        &self,
        _directory: &std::path::Path,
        _suggested_name: Option<&str>,
    ) -> oneshot::Receiver<Result<Option<std::path::PathBuf>>> {
        oneshot::channel().1
    }

    fn can_select_mixed_files_and_dirs(&self) -> bool {
        true
    }

    fn reveal_path(&self, _path: &std::path::Path) {
        unimplemented!()
    }

    fn on_quit(&self, _callback: Box<dyn FnMut() -> bool>) {}

    fn on_reopen(&self, _callback: Box<dyn FnMut()>) {
        unimplemented!()
    }

    fn on_system_sleep(&self, _callback: Box<dyn FnMut()>) {}

    fn on_system_wake(&self, _callback: Box<dyn FnMut()>) {}

    fn on_app_lifecycle(&self, callback: Box<dyn FnMut(AppLifecyclePhase)>) {
        *self.app_lifecycle_callback.borrow_mut() = Some(callback);
    }

    fn on_memory_warning(&self, callback: Box<dyn FnMut()>) {
        *self.memory_warning_callback.borrow_mut() = Some(callback);
    }

    fn set_app_identity(&self, identifier: &str, name: &str) {
        self.system_notifications.borrow_mut().app_identity =
            Some((identifier.to_string().into(), name.to_string().into()));
    }

    fn show_system_notification(&self, notification: SystemNotification) {
        let mut system_notifications = self.system_notifications.borrow_mut();
        if system_notifications.app_identity.is_none() {
            return;
        }

        let delivered = system_notifications
            .delivered
            .iter_mut()
            .find(|delivered| delivered.tag == notification.tag);
        if let Some(delivered) = delivered {
            *delivered = notification.clone();
        } else {
            system_notifications.delivered.push(notification.clone());
        }
        system_notifications.shown.push(notification);
    }

    fn dismiss_system_notification(&self, tag: &str) -> Task<()> {
        let mut system_notifications = self.system_notifications.borrow_mut();
        system_notifications
            .delivered
            .retain(|notification| notification.tag != tag);
        system_notifications
            .dismissed
            .push(SharedString::from(tag.to_string()));
        Task::ready(())
    }

    fn on_system_notification_response(
        &self,
        callback: Box<dyn FnMut(SystemNotificationResponse)>,
    ) {
        self.system_notifications.borrow_mut().response_callback = Some(callback);
    }

    fn set_menus(&self, menus: Vec<crate::Menu>, _keymap: &Keymap) {
        *self.menus.borrow_mut() = menus.into_iter().map(|menu| menu.owned()).collect()
    }

    fn get_menus(&self) -> Option<Vec<OwnedMenu>> {
        Some(self.menus.borrow().clone())
    }

    fn set_dock_menu(&self, _menu: Vec<crate::MenuItem>, _keymap: &Keymap) {}

    fn add_recent_document(&self, _paths: &Path) {}

    fn on_app_menu_action(&self, _callback: Box<dyn FnMut(&dyn crate::Action)>) {}

    fn on_will_open_app_menu(&self, _callback: Box<dyn FnMut()>) {}

    fn on_validate_app_menu_command(&self, _callback: Box<dyn FnMut(&dyn crate::Action) -> bool>) {}

    fn app_path(&self) -> Result<std::path::PathBuf> {
        unimplemented!()
    }

    fn path_for_auxiliary_executable(&self, _name: &str) -> Result<std::path::PathBuf> {
        unimplemented!()
    }

    fn set_cursor_style(&self, style: crate::CursorStyle) {
        *self.active_cursor.lock() = style;
    }

    fn hide_cursor_until_mouse_moves(&self) {}

    fn is_cursor_visible(&self) -> bool {
        true
    }

    fn should_auto_hide_scrollbars(&self) -> bool {
        false
    }

    fn read_from_clipboard(&self) -> Option<ClipboardItem> {
        self.current_clipboard_item.lock().clone()
    }

    fn write_to_clipboard(&self, item: ClipboardItem) {
        *self.current_clipboard_item.lock() = Some(item);
    }

    #[cfg(any(target_os = "linux", target_os = "freebsd"))]
    fn read_from_primary(&self) -> Option<ClipboardItem> {
        self.current_primary_item.lock().clone()
    }

    #[cfg(any(target_os = "linux", target_os = "freebsd"))]
    fn write_to_primary(&self, item: ClipboardItem) {
        *self.current_primary_item.lock() = Some(item);
    }

    #[cfg(target_os = "macos")]
    fn read_from_find_pasteboard(&self) -> Option<ClipboardItem> {
        self.current_find_pasteboard_item.lock().clone()
    }

    #[cfg(target_os = "macos")]
    fn write_to_find_pasteboard(&self, item: ClipboardItem) {
        *self.current_find_pasteboard_item.lock() = Some(item);
    }

    fn write_credentials(&self, _url: &str, _username: &str, _password: &[u8]) -> Task<Result<()>> {
        Task::ready(Ok(()))
    }

    fn read_credentials(&self, _url: &str) -> Task<Result<Option<(String, Vec<u8>)>>> {
        Task::ready(Ok(None))
    }

    fn delete_credentials(&self, _url: &str) -> Task<Result<()>> {
        Task::ready(Ok(()))
    }

    fn register_url_scheme(&self, _: &str) -> Task<anyhow::Result<()>> {
        unimplemented!()
    }

    fn open_with_system(&self, _path: &Path) {
        unimplemented!()
    }
}

impl TestScreenCaptureSource {
    /// Create a fake screen capture source, for testing.
    #[cfg(any(test, feature = "test-support"))]
    pub fn new() -> Self {
        Self {}
    }
}

struct TestKeyboardLayout;

impl PlatformKeyboardLayout for TestKeyboardLayout {
    fn id(&self) -> &str {
        "zed.keyboard.example"
    }

    fn name(&self) -> &str {
        "zed.keyboard.example"
    }
}
