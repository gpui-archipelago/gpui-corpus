// Modified by Longbridge for gpui-fast.
//! Tests of what gpui-fast adds, kept out of upstream files' test modules.

mod a11y;
mod cached_layout;
mod dependencies;
mod dispatch;
mod dynamic_textures;
mod em_metrics;
mod global_id;
mod interactive_text;
mod layers;
mod layers_lists;
mod layers_oracle;
mod layout;
mod list_measure;
mod misc;
mod number_shaping;
mod observers;
mod oracle;
mod pointer;
mod retained;
mod retained_bench;
mod scene_order;
mod scroll_to_bottom;
mod splice;
mod splice_late_layout;
mod support;
mod tab_stops;
mod text;
mod text_shaping;
mod tooltip;
mod tracked_entities;
mod truncation;
mod wheel_notifies;
