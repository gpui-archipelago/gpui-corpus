// Modified by Longbridge for gpui-fast.
//! Tests of what gpui-fast adds, kept out of upstream files' test modules.

mod a11y;
mod cached_layout;
mod dependencies;
mod dispatch;
mod global_id;
mod interactive_text;
mod layers;
mod layers_lists;
mod layers_oracle;
mod layout;
mod misc;
mod number_shaping;
mod oracle;
mod path_cache;
mod retained;
mod retained_bench;
mod scene_order;
mod scroll_to_bottom;
mod splice;
mod support;
mod text;
mod text_shaping;
mod wheel_notifies;
