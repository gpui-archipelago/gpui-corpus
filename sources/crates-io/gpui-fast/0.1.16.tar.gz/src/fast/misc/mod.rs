// Modified by Longbridge for gpui-fast.
//! Small fixes to upstream behavior, each too small for a topic of its own.
//! One file per scenario.

pub(crate) mod reentrant_window;
pub(crate) mod system_power;
pub(crate) mod touch_fling;
