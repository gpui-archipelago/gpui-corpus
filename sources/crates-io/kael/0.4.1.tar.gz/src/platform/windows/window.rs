#![deny(unsafe_op_in_unsafe_fn)]

use std::{
    cell::RefCell,
    collections::HashMap,
    num::NonZeroIsize,
    path::PathBuf,
    rc::{Rc, Weak},
    str::FromStr,
    sync::{
        Arc, OnceLock,
        atomic::{AtomicIsize, Ordering},
    },
    time::{Duration, Instant},
};

use ::util::ResultExt;
use anyhow::{Context as _, Result};
use async_task::Runnable;
use futures::channel::oneshot::{self, Receiver};
use raw_window_handle as rwh;
use smallvec::SmallVec;
use windows::{
    Win32::{
        Foundation::*,
        Graphics::Gdi::*,
        System::{Com::*, LibraryLoader::*, Memory::*, Ole::*, SystemServices::*},
        UI::{
            Controls::*, HiDpi::*, Input::KeyboardAndMouse::*, Input::*, Shell::*,
            WindowsAndMessaging::*,
        },
    },
    core::*,
};

use crate::platform::tab_manager::{TabManagerState, WindowTabManager};
use crate::*;

#[cfg(feature = "webview")]
use super::webview::WindowsWebViewHost;
#[cfg(feature = "webview")]
use crate::webview::{PlatformWebView, PlatformWebViewCommand};

const MAX_NATIVE_TEXT_BYTES: usize = 16 * 1024 * 1024;

fn task_dialog_indirect(config: &TASKDIALOGCONFIG, button: &mut i32) -> Result<()> {
    type TaskDialogIndirectFn = unsafe extern "system" fn(
        *const TASKDIALOGCONFIG,
        *mut i32,
        *mut i32,
        *mut BOOL,
    ) -> HRESULT;

    crate::with_dll_library(s!("comctl32.dll"), |common_controls| {
        let entry = unsafe { GetProcAddress(common_controls, s!("TaskDialogIndirect")) }
            .context("TaskDialogIndirect is unavailable in the active Common Controls version")?;
        let task_dialog: TaskDialogIndirectFn = unsafe { std::mem::transmute(entry) };
        unsafe { task_dialog(config, button, std::ptr::null_mut(), std::ptr::null_mut()) }
            .ok()
            .context("unable to create task dialog")
    })
}

/// Raw-input registration and cursor clipping are process-global Win32
/// resources. Only the HWND stored here may mutate or release them.
static WINDOWS_POINTER_LOCK_OWNER: AtomicIsize = AtomicIsize::new(0);

struct GlobalMemoryLock(HGLOBAL);

impl Drop for GlobalMemoryLock {
    fn drop(&mut self) {
        unsafe {
            GlobalUnlock(self.0).log_err();
        }
    }
}

pub(crate) struct WindowsWindow(pub Rc<WindowsWindowInner>);

pub struct WindowsWindowState {
    pub origin: Point<Pixels>,
    pub logical_size: Size<Pixels>,
    pub min_size: Option<Size<Pixels>>,
    pub fullscreen_restore_bounds: Bounds<Pixels>,
    pub border_offset: WindowBorderOffset,
    pub appearance: WindowAppearance,
    pub scale_factor: f32,
    pub restore_from_minimized: Option<Box<dyn FnMut(RequestFrameOptions)>>,
    pub frame_polling_requested: bool,

    pub callbacks: Callbacks,
    pub input_handler: Option<PlatformInputHandler>,
    pub pending_surrogate: Option<u16>,
    pub last_reported_modifiers: Option<Modifiers>,
    pub last_reported_capslock: Option<Capslock>,
    pub system_key_handled: bool,
    pub hovered: bool,

    pub renderer: DirectXRenderer,

    pub click_state: ClickState,
    pub system_settings: WindowsSystemSettings,
    pub current_cursor: Option<HCURSOR>,
    pub nc_button_pressed: Option<u32>,
    pub window_opacity: f32,
    pub(crate) pointer_lock: crate::game_input::NativePointerLockState,
    pub(crate) pointer_lock_saved_position: Option<POINT>,
    pub(crate) pointer_lock_absolute_position: Option<(i32, i32)>,
    pub(crate) active_pointers: HashMap<u32, PointerInputEvent>,

    pub display: WindowsDisplay,
    fullscreen: Option<StyleAndBounds>,
    initial_placement: Option<WindowOpenStatus>,
    hwnd: HWND,
    #[cfg(feature = "webview")]
    pub(crate) webviews: HashMap<SharedString, WindowsWebViewHost>,
    #[cfg(feature = "webview")]
    pub(crate) pending_webviews: HashMap<SharedString, PlatformWebView>,
}

pub(crate) struct WindowsWindowInner {
    pub(crate) hwnd: HWND,
    pub(super) this: Weak<Self>,
    drop_target_helper: IDropTargetHelper,
    pub(crate) state: RefCell<WindowsWindowState>,
    pub(crate) handle: AnyWindowHandle,
    pub(crate) hide_title_bar: bool,
    pub(crate) is_movable: bool,
    pub(crate) executor: ForegroundExecutor,
    pub(crate) windows_version: WindowsVersion,
    pub(crate) validation_number: usize,
    pub(crate) main_receiver: crossbeam_channel::Receiver<Runnable>,
    pub(crate) platform_window_handle: HWND,
    pub(crate) frame_polling_windows: Arc<FramePollingWindows>,
    pub(crate) tab_manager: WindowTabManager,
    pub(crate) uia_provider: windows::core::ComObject<GpuiUiaProvider>,
}

impl WindowsWindowState {
    fn new(
        hwnd: HWND,
        directx_devices: &DirectXDevices,
        window_params: &CREATESTRUCTW,
        current_cursor: Option<HCURSOR>,
        display: WindowsDisplay,
        min_size: Option<Size<Pixels>>,
        appearance: WindowAppearance,
        disable_direct_composition: bool,
    ) -> Result<Self> {
        let scale_factor = {
            let monitor_dpi = unsafe { GetDpiForWindow(hwnd) } as f32;
            monitor_dpi / USER_DEFAULT_SCREEN_DPI as f32
        };
        let origin = logical_point(window_params.x as f32, window_params.y as f32, scale_factor);
        let logical_size = {
            let physical_size = size(
                DevicePixels(window_params.cx),
                DevicePixels(window_params.cy),
            );
            physical_size.to_pixels(scale_factor)
        };
        let fullscreen_restore_bounds = Bounds {
            origin,
            size: logical_size,
        };
        let border_offset = WindowBorderOffset::default();
        let restore_from_minimized = None;
        let frame_polling_requested = false;
        let renderer = DirectXRenderer::new(hwnd, directx_devices, disable_direct_composition)
            .context("Creating DirectX renderer")?;
        let callbacks = Callbacks::default();
        let input_handler = None;
        let pending_surrogate = None;
        let last_reported_modifiers = None;
        let last_reported_capslock = None;
        let system_key_handled = false;
        let hovered = false;
        let click_state = ClickState::new();
        let system_settings = WindowsSystemSettings::new(display);
        let nc_button_pressed = None;
        let window_opacity = 1.0;
        let fullscreen = None;
        let initial_placement = None;

        Ok(Self {
            origin,
            logical_size,
            fullscreen_restore_bounds,
            border_offset,
            appearance,
            scale_factor,
            restore_from_minimized,
            frame_polling_requested,
            min_size,
            callbacks,
            input_handler,
            pending_surrogate,
            last_reported_modifiers,
            last_reported_capslock,
            system_key_handled,
            hovered,
            renderer,
            click_state,
            system_settings,
            current_cursor,
            nc_button_pressed,
            window_opacity,
            pointer_lock: crate::game_input::NativePointerLockState::new(true),
            pointer_lock_saved_position: None,
            pointer_lock_absolute_position: None,
            active_pointers: HashMap::default(),
            display,
            fullscreen,
            initial_placement,
            hwnd,
            #[cfg(feature = "webview")]
            webviews: HashMap::default(),
            #[cfg(feature = "webview")]
            pending_webviews: HashMap::default(),
        })
    }

    #[inline]
    pub(crate) fn is_fullscreen(&self) -> bool {
        self.fullscreen.is_some()
    }

    pub(crate) fn is_maximized(&self) -> bool {
        !self.is_fullscreen() && unsafe { IsZoomed(self.hwnd) }.as_bool()
    }

    fn bounds(&self) -> Bounds<Pixels> {
        Bounds {
            origin: self.origin,
            size: self.logical_size,
        }
    }

    // Calculate the bounds used for saving and whether the window is maximized.
    fn calculate_window_bounds(&self) -> (Bounds<Pixels>, bool) {
        let placement = unsafe {
            let mut placement = WINDOWPLACEMENT {
                length: std::mem::size_of::<WINDOWPLACEMENT>() as u32,
                ..Default::default()
            };
            GetWindowPlacement(self.hwnd, &mut placement).log_err();
            placement
        };
        (
            calculate_client_rect(
                placement.rcNormalPosition,
                self.border_offset,
                self.scale_factor,
            ),
            placement.showCmd == SW_SHOWMAXIMIZED.0 as u32,
        )
    }

    fn window_bounds(&self) -> WindowBounds {
        let (bounds, maximized) = self.calculate_window_bounds();

        if self.is_fullscreen() {
            WindowBounds::Fullscreen(self.fullscreen_restore_bounds)
        } else if maximized {
            WindowBounds::Maximized(bounds)
        } else {
            WindowBounds::Windowed(bounds)
        }
    }

    /// get the logical size of the app's drawable area.
    ///
    /// Currently, GPUI uses the logical size of the app to handle mouse interactions (such as
    /// whether the mouse collides with other elements of GPUI).
    fn content_size(&self) -> Size<Pixels> {
        self.logical_size
    }
}

impl WindowsWindowInner {
    fn new(context: &mut WindowCreateContext, hwnd: HWND, cs: &CREATESTRUCTW) -> Result<Rc<Self>> {
        let state = RefCell::new(WindowsWindowState::new(
            hwnd,
            &context.directx_devices,
            cs,
            context.current_cursor,
            context.display,
            context.min_size,
            context.appearance,
            context.disable_direct_composition,
        )?);

        let tab_manager = WindowTabManager::new(context.handle, context.tab_manager_state.clone());
        let uia_provider = GpuiUiaProvider::new(hwnd);

        Ok(Rc::new_cyclic(|this| Self {
            hwnd,
            this: this.clone(),
            drop_target_helper: context.drop_target_helper.clone(),
            state,
            handle: context.handle,
            hide_title_bar: context.hide_title_bar,
            is_movable: context.is_movable,
            executor: context.executor.clone(),
            windows_version: context.windows_version,
            validation_number: context.validation_number,
            main_receiver: context.main_receiver.clone(),
            platform_window_handle: context.platform_window_handle,
            frame_polling_windows: context.frame_polling_windows.clone(),
            tab_manager,
            uia_provider,
        }))
    }

    fn pointer_lock_owner_id(&self) -> isize {
        self.hwnd.0 as isize
    }

    fn pointer_clip_rect(&self) -> std::result::Result<RECT, GameInputError> {
        let mut rect = RECT::default();
        unsafe { GetClientRect(self.hwnd, &mut rect) }.map_err(|error| {
            GameInputError::new(
                GameInputErrorKind::Platform,
                format!("Windows failed to query the pointer-lock client bounds: {error}"),
            )
        })?;
        let mut top_left = POINT {
            x: rect.left,
            y: rect.top,
        };
        let mut bottom_right = POINT {
            x: rect.right,
            y: rect.bottom,
        };
        unsafe { ClientToScreen(self.hwnd, &mut top_left) }
            .ok()
            .map_err(|error| {
                GameInputError::new(
                    GameInputErrorKind::Platform,
                    format!("Windows failed to map the pointer-lock origin: {error}"),
                )
            })?;
        unsafe { ClientToScreen(self.hwnd, &mut bottom_right) }
            .ok()
            .map_err(|error| {
                GameInputError::new(
                    GameInputErrorKind::Platform,
                    format!("Windows failed to map the pointer-lock extent: {error}"),
                )
            })?;
        if bottom_right.x <= top_left.x || bottom_right.y <= top_left.y {
            return Err(GameInputError::new(
                GameInputErrorKind::Rejected,
                "Windows cannot lock the pointer to an empty or minimized client area",
            ));
        }
        Ok(RECT {
            left: top_left.x,
            top: top_left.y,
            right: bottom_right.x,
            bottom: bottom_right.y,
        })
    }

    fn unregister_raw_pointer(&self) -> windows::core::Result<()> {
        unsafe {
            RegisterRawInputDevices(
                &[RAWINPUTDEVICE {
                    usUsagePage: 0x01,
                    usUsage: 0x02,
                    dwFlags: RIDEV_REMOVE,
                    hwndTarget: HWND::default(),
                }],
                std::mem::size_of::<RAWINPUTDEVICE>() as u32,
            )
        }
    }

    pub(super) fn request_native_pointer_lock(&self) -> std::result::Result<(), GameInputError> {
        {
            let mut state = self.state.borrow_mut();
            if !state.pointer_lock.begin_request()? {
                return Ok(());
            }
        }

        if unsafe { GetForegroundWindow() } != self.hwnd {
            let error = GameInputError::new(
                GameInputErrorKind::Rejected,
                "Windows pointer lock requires the Kael window to be active",
            );
            return Err(self.state.borrow_mut().pointer_lock.fail(error));
        }

        let owner_id = self.pointer_lock_owner_id();
        if WINDOWS_POINTER_LOCK_OWNER
            .compare_exchange(0, owner_id, Ordering::AcqRel, Ordering::Acquire)
            .is_err_and(|owner| owner != owner_id)
        {
            let error = GameInputError::new(
                GameInputErrorKind::Rejected,
                "another Kael window currently owns the Windows pointer lock",
            );
            return Err(self.state.borrow_mut().pointer_lock.fail(error));
        }

        let mut saved_position = POINT::default();
        if let Err(error) = unsafe { GetCursorPos(&mut saved_position) } {
            WINDOWS_POINTER_LOCK_OWNER.store(0, Ordering::Release);
            let error = GameInputError::new(
                GameInputErrorKind::Platform,
                format!("Windows failed to save the cursor position: {error}"),
            );
            return Err(self.state.borrow_mut().pointer_lock.fail(error));
        }

        let register_result = unsafe {
            RegisterRawInputDevices(
                &[RAWINPUTDEVICE {
                    usUsagePage: 0x01,
                    usUsage: 0x02,
                    dwFlags: RAWINPUTDEVICE_FLAGS::default(),
                    hwndTarget: self.hwnd,
                }],
                std::mem::size_of::<RAWINPUTDEVICE>() as u32,
            )
        };
        if let Err(error) = register_result {
            WINDOWS_POINTER_LOCK_OWNER.store(0, Ordering::Release);
            let error = GameInputError::new(
                GameInputErrorKind::InitializationFailed,
                format!("Windows failed to register raw mouse input: {error}"),
            );
            return Err(self.state.borrow_mut().pointer_lock.fail(error));
        }

        let clip_rect = match self.pointer_clip_rect() {
            Ok(rect) => rect,
            Err(error) => {
                self.unregister_raw_pointer().log_err();
                WINDOWS_POINTER_LOCK_OWNER.store(0, Ordering::Release);
                return Err(self.state.borrow_mut().pointer_lock.fail(error));
            }
        };
        if let Err(error) = unsafe { ClipCursor(Some(&clip_rect)) } {
            self.unregister_raw_pointer().log_err();
            WINDOWS_POINTER_LOCK_OWNER.store(0, Ordering::Release);
            let error = GameInputError::new(
                GameInputErrorKind::Platform,
                format!("Windows failed to confine the pointer: {error}"),
            );
            return Err(self.state.borrow_mut().pointer_lock.fail(error));
        }

        unsafe { SetCursor(None) };
        let mut state = self.state.borrow_mut();
        state.pointer_lock_saved_position = Some(saved_position);
        state.pointer_lock_absolute_position = None;
        state.pointer_lock.lock();
        Ok(())
    }

    pub(super) fn release_native_pointer_lock(&self) -> std::result::Result<(), GameInputError> {
        let owner_id = self.pointer_lock_owner_id();
        let owns_global_lock = WINDOWS_POINTER_LOCK_OWNER.load(Ordering::Acquire) == owner_id;
        let mut first_error = None;

        if owns_global_lock {
            if let Err(error) = self.unregister_raw_pointer() {
                first_error = Some(GameInputError::new(
                    GameInputErrorKind::Platform,
                    format!("Windows failed to unregister raw mouse input: {error}"),
                ));
            }
            if let Err(error) = unsafe { ClipCursor(None) }
                && first_error.is_none()
            {
                first_error = Some(GameInputError::new(
                    GameInputErrorKind::Platform,
                    format!("Windows failed to release pointer confinement: {error}"),
                ));
            }

            let (saved_position, cursor) = {
                let mut state = self.state.borrow_mut();
                state.pointer_lock_absolute_position = None;
                (
                    state.pointer_lock_saved_position.take(),
                    state.current_cursor,
                )
            };
            if let Some(position) = saved_position
                && let Err(error) = unsafe { SetCursorPos(position.x, position.y) }
                && first_error.is_none()
            {
                first_error = Some(GameInputError::new(
                    GameInputErrorKind::Platform,
                    format!("Windows failed to restore the cursor position: {error}"),
                ));
            }
            unsafe { SetCursor(cursor) };
            let _ = WINDOWS_POINTER_LOCK_OWNER.compare_exchange(
                owner_id,
                0,
                Ordering::AcqRel,
                Ordering::Acquire,
            );
        } else {
            let mut state = self.state.borrow_mut();
            state.pointer_lock_saved_position = None;
            state.pointer_lock_absolute_position = None;
        }

        let mut state = self.state.borrow_mut();
        if let Some(error) = first_error {
            return Err(state.pointer_lock.fail(error));
        }
        state.pointer_lock.unlock();
        Ok(())
    }

    pub(super) fn refresh_native_pointer_clip(&self) -> std::result::Result<(), GameInputError> {
        if !self.is_native_pointer_locked() {
            return Ok(());
        }
        let rect = self.pointer_clip_rect()?;
        unsafe { ClipCursor(Some(&rect)) }.map_err(|error| {
            GameInputError::new(
                GameInputErrorKind::Platform,
                format!("Windows failed to update pointer confinement: {error}"),
            )
        })
    }

    pub(super) fn is_native_pointer_locked(&self) -> bool {
        self.state.borrow().pointer_lock.status() == PointerLockStatus::Locked
    }

    pub(super) fn fail_native_pointer_lock(&self, error: GameInputError) {
        self.release_native_pointer_lock().log_err();
        self.state.borrow_mut().pointer_lock.fail(error);
    }

    fn toggle_fullscreen(&self) {
        let Some(this) = self.this.upgrade() else {
            log::error!("Unable to toggle fullscreen: window has been dropped");
            return;
        };
        self.executor
            .spawn(async move {
                let mut lock = this.state.borrow_mut();
                let StyleAndBounds {
                    style,
                    x,
                    y,
                    cx,
                    cy,
                } = if let Some(state) = lock.fullscreen.take() {
                    state
                } else {
                    let (window_bounds, _) = lock.calculate_window_bounds();
                    lock.fullscreen_restore_bounds = window_bounds;
                    let style = WINDOW_STYLE(unsafe { get_window_long(this.hwnd, GWL_STYLE) } as _);
                    let mut rc = RECT::default();
                    unsafe { GetWindowRect(this.hwnd, &mut rc) }.log_err();
                    let _ = lock.fullscreen.insert(StyleAndBounds {
                        style,
                        x: rc.left,
                        y: rc.top,
                        cx: rc.right - rc.left,
                        cy: rc.bottom - rc.top,
                    });
                    let style = style
                        & !(WS_THICKFRAME
                            | WS_SYSMENU
                            | WS_MAXIMIZEBOX
                            | WS_MINIMIZEBOX
                            | WS_CAPTION);
                    let physical_bounds = lock.display.physical_bounds();
                    StyleAndBounds {
                        style,
                        x: physical_bounds.left().0,
                        y: physical_bounds.top().0,
                        cx: physical_bounds.size.width.0,
                        cy: physical_bounds.size.height.0,
                    }
                };
                drop(lock);
                unsafe { set_window_long(this.hwnd, GWL_STYLE, style.0 as isize) };
                unsafe {
                    SetWindowPos(
                        this.hwnd,
                        None,
                        x,
                        y,
                        cx,
                        cy,
                        SWP_FRAMECHANGED | SWP_NOACTIVATE | SWP_NOZORDER,
                    )
                }
                .log_err();
            })
            .detach();
    }

    fn set_window_placement(&self) -> Result<()> {
        let Some(open_status) = self.state.borrow_mut().initial_placement.take() else {
            return Ok(());
        };
        match open_status.state {
            WindowOpenState::Maximized => unsafe {
                SetWindowPlacement(self.hwnd, &open_status.placement)?;
                ShowWindowAsync(self.hwnd, SW_MAXIMIZE).ok()?;
            },
            WindowOpenState::Fullscreen => {
                unsafe { SetWindowPlacement(self.hwnd, &open_status.placement)? };
                self.toggle_fullscreen();
            }
            WindowOpenState::Windowed => unsafe {
                SetWindowPlacement(self.hwnd, &open_status.placement)?;
            },
        }
        Ok(())
    }
}

#[derive(Default)]
pub(crate) struct Callbacks {
    pub(crate) request_frame: Option<Box<dyn FnMut(RequestFrameOptions)>>,
    pub(crate) input: Option<Box<dyn FnMut(crate::PlatformInput) -> DispatchEventResult>>,
    pub(crate) active_status_change: Option<Box<dyn FnMut(bool)>>,
    pub(crate) hovered_status_change: Option<Box<dyn FnMut(bool)>>,
    pub(crate) resize: Option<Box<dyn FnMut(Size<Pixels>, f32)>>,
    pub(crate) moved: Option<Box<dyn FnMut()>>,
    pub(crate) should_close: Option<Box<dyn FnMut() -> bool>>,
    pub(crate) close: Option<Box<dyn FnOnce()>>,
    pub(crate) hit_test_window_control: Option<Box<dyn FnMut() -> Option<WindowControlArea>>>,
    pub(crate) appearance_changed: Option<Box<dyn FnMut()>>,
}

struct WindowCreateContext {
    inner: Option<Result<Rc<WindowsWindowInner>>>,
    handle: AnyWindowHandle,
    hide_title_bar: bool,
    display: WindowsDisplay,
    is_movable: bool,
    min_size: Option<Size<Pixels>>,
    executor: ForegroundExecutor,
    current_cursor: Option<HCURSOR>,
    windows_version: WindowsVersion,
    drop_target_helper: IDropTargetHelper,
    validation_number: usize,
    main_receiver: crossbeam_channel::Receiver<Runnable>,
    platform_window_handle: HWND,
    appearance: WindowAppearance,
    disable_direct_composition: bool,
    directx_devices: DirectXDevices,
    tab_manager_state: Arc<std::sync::Mutex<TabManagerState>>,
    frame_polling_windows: Arc<FramePollingWindows>,
}

impl WindowsWindow {
    pub(crate) fn new(
        handle: AnyWindowHandle,
        params: WindowParams,
        creation_info: WindowCreationInfo,
    ) -> Result<Self> {
        let WindowCreationInfo {
            icon,
            executor,
            current_cursor,
            windows_version,
            drop_target_helper,
            validation_number,
            main_receiver,
            platform_window_handle,
            disable_direct_composition,
            directx_devices,
            tab_manager_state,
            owner_window,
            frame_polling_windows,
        } = creation_info;
        register_window_class(icon)?;
        let hide_title_bar = params
            .titlebar
            .as_ref()
            .map(|titlebar| titlebar.appears_transparent)
            .unwrap_or(true);
        let window_name = HSTRING::from(
            params
                .titlebar
                .as_ref()
                .and_then(|titlebar| titlebar.title.as_ref())
                .map(|title| title.as_ref())
                .unwrap_or(""),
        );

        let (mut dwexstyle, dwstyle) = if params.kind == WindowKind::PopUp {
            (WS_EX_TOOLWINDOW, WINDOW_STYLE(0x0))
        } else if params.kind == WindowKind::Overlay {
            (WS_EX_TOOLWINDOW | WS_EX_TOPMOST, WS_POPUP)
        } else {
            let mut dwstyle = WS_SYSMENU;

            if params.is_resizable {
                dwstyle |= WS_THICKFRAME | WS_MAXIMIZEBOX;
            }

            if params.is_minimizable {
                dwstyle |= WS_MINIMIZEBOX;
            }

            let mut dwexstyle = if owner_window.is_some() {
                WINDOW_EX_STYLE(0)
            } else {
                WS_EX_APPWINDOW
            };
            if owner_window.is_some() && params.kind == WindowKind::Floating {
                dwexstyle |= WS_EX_TOOLWINDOW;
            }

            (dwexstyle, dwstyle)
        };
        if params.mouse_passthrough {
            dwexstyle |= WS_EX_TRANSPARENT | WS_EX_LAYERED;
        }
        if !disable_direct_composition {
            dwexstyle |= WS_EX_NOREDIRECTIONBITMAP;
        }

        let hinstance = get_module_handle()?;
        let display = if let Some(display_id) = params.display_id {
            WindowsDisplay::new(display_id)
                .ok_or_else(|| anyhow::anyhow!("requested display is unavailable"))?
        } else {
            WindowsDisplay::primary_monitor()
                .ok_or_else(|| anyhow::anyhow!("primary display is unavailable"))?
        };
        let appearance = system_appearance().unwrap_or_default();
        let mut context = WindowCreateContext {
            inner: None,
            handle,
            hide_title_bar,
            display,
            is_movable: params.is_movable,
            min_size: params.window_min_size,
            executor,
            current_cursor,
            windows_version,
            drop_target_helper,
            validation_number,
            main_receiver,
            platform_window_handle,
            appearance,
            disable_direct_composition,
            directx_devices,
            tab_manager_state,
            frame_polling_windows,
        };
        let creation_result = unsafe {
            CreateWindowExW(
                dwexstyle,
                WINDOW_CLASS_NAME,
                &window_name,
                dwstyle,
                CW_USEDEFAULT,
                CW_USEDEFAULT,
                CW_USEDEFAULT,
                CW_USEDEFAULT,
                owner_window,
                None,
                Some(hinstance.into()),
                Some(&context as *const _ as *const _),
            )
        };

        // Failure to create a `WindowsWindowState` can cause window creation to fail,
        // so check the inner result first.
        let this = context.inner.take().ok_or_else(|| {
            anyhow::anyhow!("native window creation did not initialize its state")
        })??;
        let hwnd = creation_result?;
        if let Some(owner_window) = owner_window {
            unsafe { set_window_long(hwnd, GWLP_HWNDPARENT, owner_window.0 as isize) };
        }

        register_drag_drop(&this)?;
        configure_dwm_dark_mode(hwnd, appearance);
        this.state.borrow_mut().border_offset.update(hwnd)?;
        let placement = retrieve_window_placement(
            hwnd,
            display,
            params.bounds,
            this.state.borrow().scale_factor,
            this.state.borrow().border_offset,
        )?;
        if params.show {
            unsafe { SetWindowPlacement(hwnd, &placement)? };
        } else {
            this.state.borrow_mut().initial_placement = Some(WindowOpenStatus {
                placement,
                state: WindowOpenState::Windowed,
            });
        }

        Ok(Self(this))
    }
}

impl rwh::HasWindowHandle for WindowsWindow {
    fn window_handle(&self) -> std::result::Result<rwh::WindowHandle<'_>, rwh::HandleError> {
        let raw = rwh::Win32WindowHandle::new(unsafe {
            NonZeroIsize::new_unchecked(self.0.hwnd.0 as isize)
        })
        .into();
        Ok(unsafe { rwh::WindowHandle::borrow_raw(raw) })
    }
}

impl rwh::HasDisplayHandle for WindowsWindow {
    fn display_handle(&self) -> std::result::Result<rwh::DisplayHandle<'_>, rwh::HandleError> {
        Ok(unsafe { rwh::DisplayHandle::borrow_raw(rwh::WindowsDisplayHandle::new().into()) })
    }
}

impl Drop for WindowsWindow {
    fn drop(&mut self) {
        if let Err(error) = self.0.release_native_pointer_lock() {
            log::error!("failed to release Windows pointer lock while dropping window: {error}");
        }
        self.0.frame_polling_windows.set(self.0.hwnd, false);
        // Clean up tab manager tracking for this window.
        self.0.tab_manager.remove_window();
        #[cfg(feature = "webview")]
        self.0.state.borrow_mut().webviews.clear();

        // clone this `Rc` to prevent early release of the pointer
        let this = self.0.clone();
        self.0
            .executor
            .spawn(async move {
                let handle = this.hwnd;
                unsafe {
                    RevokeDragDrop(handle).log_err();
                    DestroyWindow(handle).log_err();
                }
            })
            .detach();
    }
}

impl PlatformWindow for WindowsWindow {
    fn bounds(&self) -> Bounds<Pixels> {
        self.0.state.borrow().bounds()
    }

    fn is_maximized(&self) -> bool {
        self.0.state.borrow().is_maximized()
    }

    fn window_bounds(&self) -> WindowBounds {
        self.0.state.borrow().window_bounds()
    }

    /// get the logical size of the app's drawable area.
    ///
    /// Currently, GPUI uses the logical size of the app to handle mouse interactions (such as
    /// whether the mouse collides with other elements of GPUI).
    fn content_size(&self) -> Size<Pixels> {
        self.0.state.borrow().content_size()
    }

    fn resize(&mut self, size: Size<Pixels>) {
        let hwnd = self.0.hwnd;
        let bounds =
            crate::bounds(self.bounds().origin, size).to_device_pixels(self.scale_factor());
        let rect = calculate_window_rect(bounds, self.0.state.borrow().border_offset);

        self.0
            .executor
            .spawn(async move {
                unsafe {
                    SetWindowPos(
                        hwnd,
                        None,
                        bounds.origin.x.0,
                        bounds.origin.y.0,
                        rect.right - rect.left,
                        rect.bottom - rect.top,
                        SWP_NOMOVE,
                    )
                    .context("unable to set window content size")
                    .log_err();
                }
            })
            .detach();
    }

    fn scale_factor(&self) -> f32 {
        self.0.state.borrow().scale_factor
    }

    fn appearance(&self) -> WindowAppearance {
        self.0.state.borrow().appearance
    }

    fn display(&self) -> Option<Rc<dyn PlatformDisplay>> {
        Some(Rc::new(self.0.state.borrow().display))
    }

    fn mouse_position(&self) -> Point<Pixels> {
        let scale_factor = self.scale_factor();
        let point = unsafe {
            let mut point: POINT = std::mem::zeroed();
            GetCursorPos(&mut point)
                .context("unable to get cursor position")
                .log_err();
            ScreenToClient(self.0.hwnd, &mut point).ok().log_err();
            point
        };
        logical_point(point.x as f32, point.y as f32, scale_factor)
    }

    fn modifiers(&self) -> Modifiers {
        current_modifiers()
    }

    fn capslock(&self) -> Capslock {
        current_capslock()
    }

    fn set_input_handler(&mut self, input_handler: PlatformInputHandler) {
        self.0.state.borrow_mut().input_handler = Some(input_handler);
    }

    fn take_input_handler(&mut self) -> Option<PlatformInputHandler> {
        self.0.state.borrow_mut().input_handler.take()
    }

    fn prompt(
        &self,
        level: PromptLevel,
        msg: &str,
        detail: Option<&str>,
        answers: &[PromptButton],
    ) -> Option<Receiver<usize>> {
        const MAX_NATIVE_PROMPT_BUTTONS: usize = 64;
        if answers.is_empty() || answers.len() > MAX_NATIVE_PROMPT_BUTTONS {
            log::warn!(
                "using the framework prompt renderer for an unsupported native button count: {}",
                answers.len()
            );
            return None;
        }

        let (done_tx, done_rx) = oneshot::channel();
        let msg = msg.to_string();
        let detail_string = detail.map(|detail| detail.to_string());
        let handle = self.0.hwnd;
        let answers = answers.to_vec();
        self.0
            .executor
            .spawn(async move {
                unsafe {
                    let mut config = TASKDIALOGCONFIG::default();
                    config.cbSize = std::mem::size_of::<TASKDIALOGCONFIG>() as _;
                    config.hwndParent = handle;
                    let title;
                    let main_icon;
                    match level {
                        crate::PromptLevel::Info => {
                            title = windows::core::w!("Info");
                            main_icon = TD_INFORMATION_ICON;
                        }
                        crate::PromptLevel::Warning => {
                            title = windows::core::w!("Warning");
                            main_icon = TD_WARNING_ICON;
                        }
                        crate::PromptLevel::Critical => {
                            title = windows::core::w!("Critical");
                            main_icon = TD_ERROR_ICON;
                        }
                    };
                    config.pszWindowTitle = title;
                    config.Anonymous1.pszMainIcon = main_icon;
                    let instruction = HSTRING::from(msg);
                    config.pszMainInstruction = PCWSTR::from_raw(instruction.as_ptr());
                    let hints_encoded;
                    if let Some(ref hints) = detail_string {
                        hints_encoded = HSTRING::from(hints);
                        config.pszContent = PCWSTR::from_raw(hints_encoded.as_ptr());
                    };
                    let mut button_id_map = Vec::with_capacity(answers.len());
                    let mut buttons = Vec::new();
                    let mut btn_encoded = Vec::new();
                    let cancel_index = answers.iter().position(PromptButton::is_cancel);
                    for (index, btn) in answers.iter().enumerate() {
                        let encoded = HSTRING::from(btn.label().as_ref());
                        let button_id = if Some(index) == cancel_index {
                            IDCANCEL.0
                        } else {
                            1_000 + index as i32
                        };
                        button_id_map.push(button_id);
                        buttons.push(TASKDIALOG_BUTTON {
                            nButtonID: button_id,
                            pszButtonText: PCWSTR::from_raw(encoded.as_ptr()),
                        });
                        btn_encoded.push(encoded);
                    }
                    config.cButtons = buttons.len() as _;
                    config.pButtons = buttons.as_ptr();

                    config.pfCallback = None;
                    let mut res = std::mem::zeroed();
                    let result = task_dialog_indirect(&config, &mut res);
                    let fallback = cancel_index.unwrap_or_default();
                    let clicked = result
                        .log_err()
                        .and_then(|_| {
                            button_id_map
                                .iter()
                                .position(|&button_id| button_id == res)
                        })
                        .unwrap_or_else(|| {
                            log::warn!(
                                "native prompt produced no valid response; selecting fallback answer {fallback}"
                            );
                            fallback
                        });
                    let _ = done_tx.send(clicked);
                }
            })
            .detach();

        Some(done_rx)
    }

    fn activate(&self) {
        let hwnd = self.0.hwnd;
        let this = self.0.clone();
        self.0
            .executor
            .spawn(async move {
                this.set_window_placement().log_err();

                unsafe {
                    // If the window is minimized, restore it.
                    if IsIconic(hwnd).as_bool() {
                        ShowWindowAsync(hwnd, SW_RESTORE).ok().log_err();
                    }

                    SetActiveWindow(hwnd).log_err();
                    SetFocus(Some(hwnd)).log_err();
                }

                // premium ragebait by windows, this is needed because the window
                // must have received an input event to be able to set itself to foreground
                // so let's just simulate user input as that seems to be the most reliable way
                // some more info: https://gist.github.com/Aetopia/1581b40f00cc0cadc93a0e8ccb65dc8c
                // bonus: this bug also doesn't manifest if you have vs attached to the process
                let inputs = [
                    INPUT {
                        r#type: INPUT_KEYBOARD,
                        Anonymous: INPUT_0 {
                            ki: KEYBDINPUT {
                                wVk: VK_MENU,
                                dwFlags: KEYBD_EVENT_FLAGS(0),
                                ..Default::default()
                            },
                        },
                    },
                    INPUT {
                        r#type: INPUT_KEYBOARD,
                        Anonymous: INPUT_0 {
                            ki: KEYBDINPUT {
                                wVk: VK_MENU,
                                dwFlags: KEYEVENTF_KEYUP,
                                ..Default::default()
                            },
                        },
                    },
                ];
                unsafe { SendInput(&inputs, std::mem::size_of::<INPUT>() as i32) };

                // todo(windows)
                // crate `windows 0.56` reports true as Err
                unsafe { SetForegroundWindow(hwnd).as_bool() };
            })
            .detach();
    }

    fn is_active(&self) -> bool {
        self.0.hwnd == unsafe { GetActiveWindow() }
    }

    fn is_hovered(&self) -> bool {
        self.0.state.borrow().hovered
    }

    fn set_title(&mut self, title: &str) {
        unsafe { SetWindowTextW(self.0.hwnd, &HSTRING::from(title)) }
            .inspect_err(|e| log::error!("Set title failed: {e}"))
            .ok();
        // Keep the tab manager's title in sync for tabbed_windows() results.
        self.0.tab_manager.set_title(title.to_owned().into());
    }

    fn set_background_appearance(&self, background_appearance: WindowBackgroundAppearance) {
        let hwnd = self.0.hwnd;

        match background_appearance {
            WindowBackgroundAppearance::Opaque => {
                // ACCENT_DISABLED
                set_window_composition_attribute(hwnd, None, 0);
            }
            WindowBackgroundAppearance::Transparent => {
                // Use ACCENT_ENABLE_TRANSPARENTGRADIENT for transparent background
                set_window_composition_attribute(hwnd, None, 2);
            }
            WindowBackgroundAppearance::Blurred => {
                // Enable acrylic blur
                // ACCENT_ENABLE_ACRYLICBLURBEHIND
                set_window_composition_attribute(hwnd, Some((0, 0, 0, 0)), 4);
            }
        }
    }

    fn set_opacity(&self, opacity: f32) {
        let hwnd = self.0.hwnd;
        self.0.state.borrow_mut().window_opacity = opacity;
        let alpha = (opacity.clamp(0.0, 1.0) * u8::MAX as f32).round() as u8;

        unsafe {
            let ex_style = GetWindowLongW(hwnd, GWL_EXSTYLE);
            if ex_style & WS_EX_LAYERED.0 as i32 == 0 {
                let _ = SetWindowLongW(hwnd, GWL_EXSTYLE, ex_style | WS_EX_LAYERED.0 as i32);
                let _ = SetWindowPos(
                    hwnd,
                    None,
                    0,
                    0,
                    0,
                    0,
                    SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED,
                );
            }
            SetLayeredWindowAttributes(hwnd, COLORREF(0), alpha, LWA_ALPHA).log_err();
        }
    }

    fn set_always_on_top(&self, always_on_top: bool) {
        let insert_after = if always_on_top {
            Some(HWND_TOPMOST)
        } else {
            Some(HWND_NOTOPMOST)
        };
        unsafe {
            SetWindowPos(
                self.0.hwnd,
                insert_after,
                0,
                0,
                0,
                0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE,
            )
            .log_err();
        }
    }

    fn set_frame_polling(&self, active: bool) {
        self.0.state.borrow_mut().frame_polling_requested = active;
        let eligible = active
            && unsafe { IsWindowVisible(self.0.hwnd).as_bool() }
            && !unsafe { IsIconic(self.0.hwnd).as_bool() };
        self.0.frame_polling_windows.set(self.0.hwnd, eligible);
    }

    fn close(&self) {
        unsafe {
            PostMessageW(
                Some(self.0.hwnd),
                WM_CLOSE,
                WPARAM::default(),
                LPARAM::default(),
            )
            .log_err();
        }
    }

    fn minimize(&self) {
        unsafe { ShowWindowAsync(self.0.hwnd, SW_MINIMIZE).ok().log_err() };
    }

    fn zoom(&self) {
        unsafe {
            if IsWindowVisible(self.0.hwnd).as_bool() {
                ShowWindowAsync(self.0.hwnd, SW_MAXIMIZE).ok().log_err();
            } else if let Some(status) = self.0.state.borrow_mut().initial_placement.as_mut() {
                status.state = WindowOpenState::Maximized;
            }
        }
    }

    fn toggle_fullscreen(&self) {
        if unsafe { IsWindowVisible(self.0.hwnd).as_bool() } {
            self.0.toggle_fullscreen();
        } else if let Some(status) = self.0.state.borrow_mut().initial_placement.as_mut() {
            status.state = WindowOpenState::Fullscreen;
        }
    }

    fn is_fullscreen(&self) -> bool {
        self.0.state.borrow().is_fullscreen()
    }

    fn on_request_frame(&self, callback: Box<dyn FnMut(RequestFrameOptions)>) {
        self.0.state.borrow_mut().callbacks.request_frame = Some(callback);
    }

    fn on_input(&self, callback: Box<dyn FnMut(PlatformInput) -> DispatchEventResult>) {
        self.0.state.borrow_mut().callbacks.input = Some(callback);
    }

    fn game_input_capabilities(&self) -> GameInputCapabilities {
        let gamepads = if cfg!(feature = "game-input") {
            GameInputAvailability::Available
        } else {
            GameInputAvailability::DisabledAtCompileTime
        };
        GameInputCapabilities::new(GameInputAvailability::Available, gamepads)
    }

    fn pointer_lock_status(&self) -> PointerLockStatus {
        self.0.state.borrow().pointer_lock.status()
    }

    fn request_pointer_lock(&self) -> std::result::Result<(), GameInputError> {
        self.0.request_native_pointer_lock()
    }

    fn exit_pointer_lock(&self) -> std::result::Result<(), GameInputError> {
        self.0.release_native_pointer_lock()
    }

    fn pointer_lock_error(&self) -> Option<GameInputError> {
        self.0.state.borrow().pointer_lock.error()
    }

    fn on_active_status_change(&self, callback: Box<dyn FnMut(bool)>) {
        self.0.state.borrow_mut().callbacks.active_status_change = Some(callback);
    }

    fn on_hover_status_change(&self, callback: Box<dyn FnMut(bool)>) {
        self.0.state.borrow_mut().callbacks.hovered_status_change = Some(callback);
    }

    fn on_resize(&self, callback: Box<dyn FnMut(Size<Pixels>, f32)>) {
        self.0.state.borrow_mut().callbacks.resize = Some(callback);
    }

    fn on_moved(&self, callback: Box<dyn FnMut()>) {
        self.0.state.borrow_mut().callbacks.moved = Some(callback);
    }

    fn on_should_close(&self, callback: Box<dyn FnMut() -> bool>) {
        self.0.state.borrow_mut().callbacks.should_close = Some(callback);
    }

    fn on_close(&self, callback: Box<dyn FnOnce()>) {
        self.0.state.borrow_mut().callbacks.close = Some(callback);
    }

    fn on_hit_test_window_control(&self, callback: Box<dyn FnMut() -> Option<WindowControlArea>>) {
        self.0.state.borrow_mut().callbacks.hit_test_window_control = Some(callback);
    }

    fn on_appearance_changed(&self, callback: Box<dyn FnMut()>) {
        self.0.state.borrow_mut().callbacks.appearance_changed = Some(callback);
    }

    #[cfg(feature = "webview")]
    fn sync_webviews(&mut self, webviews: &[PlatformWebView]) {
        super::webview::sync_webviews(&self.0, webviews);
    }

    #[cfg(feature = "webview")]
    fn dispatch_webview_command(&mut self, command: PlatformWebViewCommand) -> anyhow::Result<()> {
        super::webview::dispatch_webview_command(&self.0, command)
    }

    fn print(&mut self, job: PlatformPrintJob) -> anyhow::Result<()> {
        super::print::print_job(self.0.hwnd, job, false)
    }

    fn show_print_dialog(&mut self, job: PlatformPrintJob) -> anyhow::Result<()> {
        super::print::print_job(self.0.hwnd, job, true)
    }

    fn export_scene_png(&self, scene: &Scene) -> std::result::Result<Image, WindowCaptureError> {
        let readback = self
            .0
            .state
            .borrow_mut()
            .renderer
            .render_scene_to_bgra(scene)
            .map_err(|error| WindowCaptureError::Backend(error.to_string()))?;
        crate::platform::encode_premultiplied_bgra_png(
            readback.width,
            readback.height,
            readback.premultiplied_bgra,
        )
        .map_err(|error| WindowCaptureError::Backend(error.to_string()))
    }

    fn draw(&self, scene: &Scene) {
        self.0.state.borrow_mut().renderer.draw(scene).log_err();
    }

    fn set_atlas_byte_budget(&self, budget: Option<u64>) {
        self.0
            .state
            .borrow_mut()
            .renderer
            .set_atlas_byte_budget(budget);
    }

    fn sprite_atlas(&self) -> Arc<dyn PlatformAtlas> {
        self.0.state.borrow().renderer.sprite_atlas()
    }

    fn get_raw_handle(&self) -> HWND {
        self.0.hwnd
    }

    fn gpu_specs(&self) -> Option<GpuSpecs> {
        self.0.state.borrow().renderer.gpu_specs().log_err()
    }

    fn update_ime_position(&self, _bounds: Bounds<Pixels>) {
        // There is no such thing on Windows.
    }

    fn show(&self) {
        let this = self.0.clone();
        self.0
            .executor
            .spawn(async move {
                unsafe {
                    let _ = ShowWindow(this.hwnd, SW_SHOW);
                }
            })
            .detach();
    }

    fn hide(&self) {
        let this = self.0.clone();
        self.0
            .executor
            .spawn(async move {
                unsafe {
                    let _ = ShowWindow(this.hwnd, SW_HIDE);
                }
            })
            .detach();
    }

    fn is_visible(&self) -> bool {
        unsafe { IsWindowVisible(self.0.hwnd).as_bool() }
    }

    fn set_mouse_passthrough(&self, passthrough: bool) {
        unsafe {
            let ex_style = GetWindowLongW(self.0.hwnd, GWL_EXSTYLE);
            let new_style = if passthrough {
                ex_style | (WS_EX_TRANSPARENT.0 as i32) | (WS_EX_LAYERED.0 as i32)
            } else {
                let mut style = ex_style & !(WS_EX_TRANSPARENT.0 as i32);
                if self.0.state.borrow().window_opacity >= 1.0 {
                    style &= !(WS_EX_LAYERED.0 as i32);
                }
                style
            };
            if new_style != ex_style {
                let _ = SetWindowLongW(self.0.hwnd, GWL_EXSTYLE, new_style);
                let _ = SetWindowPos(
                    self.0.hwnd,
                    None,
                    0,
                    0,
                    0,
                    0,
                    SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED,
                );
            }
        }
    }

    fn show_character_palette(&self) {
        // Simulate Win+. keystroke to open the Windows Emoji Picker.
        // This is the most reliable approach across Windows 10/11.
        let inputs = [
            INPUT {
                r#type: INPUT_KEYBOARD,
                Anonymous: INPUT_0 {
                    ki: KEYBDINPUT {
                        wVk: VK_LWIN,
                        wScan: 0,
                        dwFlags: KEYEVENTF_EXTENDEDKEY,
                        time: 0,
                        dwExtraInfo: 0,
                    },
                },
            },
            INPUT {
                r#type: INPUT_KEYBOARD,
                Anonymous: INPUT_0 {
                    ki: KEYBDINPUT {
                        wVk: VK_OEM_PERIOD,
                        wScan: 0,
                        dwFlags: KEYBD_EVENT_FLAGS(0),
                        time: 0,
                        dwExtraInfo: 0,
                    },
                },
            },
            INPUT {
                r#type: INPUT_KEYBOARD,
                Anonymous: INPUT_0 {
                    ki: KEYBDINPUT {
                        wVk: VK_OEM_PERIOD,
                        wScan: 0,
                        dwFlags: KEYEVENTF_KEYUP,
                        time: 0,
                        dwExtraInfo: 0,
                    },
                },
            },
            INPUT {
                r#type: INPUT_KEYBOARD,
                Anonymous: INPUT_0 {
                    ki: KEYBDINPUT {
                        wVk: VK_LWIN,
                        wScan: 0,
                        dwFlags: KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP,
                        time: 0,
                        dwExtraInfo: 0,
                    },
                },
            },
        ];
        unsafe {
            SendInput(&inputs, std::mem::size_of::<INPUT>() as i32);
        }
    }

    fn set_progress_bar(&self, state: crate::ProgressBarState) {
        unsafe {
            let taskbar: std::result::Result<ITaskbarList3, windows::core::Error> =
                CoCreateInstance(&TaskbarList, None, CLSCTX_INPROC_SERVER);
            let Ok(taskbar) = taskbar else { return };
            if taskbar.HrInit().is_err() {
                return;
            }

            let hwnd = self.0.hwnd;
            match state {
                crate::ProgressBarState::None => {
                    let _ = taskbar.SetProgressState(hwnd, TBPF_NOPROGRESS);
                }
                crate::ProgressBarState::Indeterminate => {
                    let _ = taskbar.SetProgressState(hwnd, TBPF_INDETERMINATE);
                }
                crate::ProgressBarState::Normal(pct) => {
                    let _ = taskbar.SetProgressState(hwnd, TBPF_NORMAL);
                    let _ = taskbar.SetProgressValue(hwnd, (pct * 100.0) as u64, 100);
                }
                crate::ProgressBarState::Error(pct) => {
                    let _ = taskbar.SetProgressState(hwnd, TBPF_ERROR);
                    let _ = taskbar.SetProgressValue(hwnd, (pct * 100.0) as u64, 100);
                }
                crate::ProgressBarState::Paused(pct) => {
                    let _ = taskbar.SetProgressState(hwnd, TBPF_PAUSED);
                    let _ = taskbar.SetProgressValue(hwnd, (pct * 100.0) as u64, 100);
                }
            }
        }
    }

    fn display_refresh_rate(&self) -> Option<f32> {
        self.0.state.borrow().display.refresh_rate()
    }

    fn set_tabbing_identifier(&self, identifier: Option<String>) {
        self.0.tab_manager.set_tabbing_identifier(identifier);
    }

    fn merge_all_windows(&self) {
        self.0.tab_manager.merge_all_windows();
    }

    fn move_tab_to_new_window(&self) {
        self.0.tab_manager.move_tab_to_new_window();
    }

    fn tabbed_windows(&self) -> Option<Vec<SystemWindowTab>> {
        self.0.tab_manager.tabbed_windows()
    }

    fn update_accessibility_tree(
        &mut self,
        tree: &crate::AccessibilityTree,
    ) -> Vec<crate::AccessibilityActionRequest> {
        use super::accessibility::{AccessibleElementInfo, AccessibleRole};
        let provider = &self.0.uia_provider;
        provider.clear_elements();
        for (_, node) in &tree.nodes {
            if node.id == tree.root {
                continue;
            }
            let role = AccessibleRole::from(node.role);
            let mut info = AccessibleElementInfo::new(role);
            if let Some(ref label) = node.label {
                info = info.with_name(label.clone());
            }
            if let Some(ref value) = node.value {
                info = match value {
                    crate::AccessibilityValue::Text(text) => {
                        info.with_text_value(text.clone()).with_value(text.clone())
                    }
                    crate::AccessibilityValue::Number(n) => info.with_value(n.to_string()),
                    crate::AccessibilityValue::Range {
                        current,
                        min,
                        max,
                        step,
                    } => info
                        .with_range_value(*current, *min, *max, *step)
                        .with_value(current.to_string()),
                    crate::AccessibilityValue::Toggle(value) => {
                        info.with_toggle_value(*value).with_value(value.to_string())
                    }
                };
            }
            info = info
                .with_node_id(node.id)
                .with_actions(node.actions.clone());
            info.element_id = node.id.0 as u32;
            provider.update_element(info);
        }
        if let Some(focused) = tree.focused_node() {
            provider.set_focused_element(Some(focused.0 as u32));
        } else {
            provider.set_focused_element(None);
        }
        provider.drain_actions()
    }
}

#[implement(IDropTarget)]
struct WindowsDragDropHandler(pub Rc<WindowsWindowInner>);

impl WindowsDragDropHandler {
    fn handle_drag_drop(&self, input: PlatformInput) {
        let mut lock = self.0.state.borrow_mut();
        if let Some(mut func) = lock.callbacks.input.take() {
            drop(lock);
            super::catch_platform_callback("drag-and-drop input", (), || {
                let _ = func(input);
            });
            self.0.state.borrow_mut().callbacks.input = Some(func);
        }
    }
}

#[allow(non_snake_case)]
impl IDropTarget_Impl for WindowsDragDropHandler_Impl {
    fn DragEnter(
        &self,
        pdataobj: windows::core::Ref<IDataObject>,
        _grfkeystate: MODIFIERKEYS_FLAGS,
        pt: &POINTL,
        pdweffect: *mut DROPEFFECT,
    ) -> windows::core::Result<()> {
        unsafe {
            let idata_obj = pdataobj.ok()?;
            let cursor_position = POINT { x: pt.x, y: pt.y };
            if let Some(data) = external_drop_data_from_data_object(&idata_obj) {
                *pdweffect = DROPEFFECT_COPY;
                let mut cursor_position = cursor_position;
                ScreenToClient(self.0.hwnd, &mut cursor_position)
                    .ok()
                    .log_err();
                let scale_factor = self.0.state.borrow().scale_factor;
                let position = logical_point(
                    cursor_position.x as f32,
                    cursor_position.y as f32,
                    scale_factor,
                );
                let input = file_drop_entered_event(position, data);
                self.handle_drag_drop(input);
            } else {
                *pdweffect = DROPEFFECT_NONE;
            }
            self.0
                .drop_target_helper
                .DragEnter(self.0.hwnd, idata_obj, &cursor_position, *pdweffect)
                .log_err();
        }
        Ok(())
    }

    fn DragOver(
        &self,
        _grfkeystate: MODIFIERKEYS_FLAGS,
        pt: &POINTL,
        pdweffect: *mut DROPEFFECT,
    ) -> windows::core::Result<()> {
        let mut cursor_position = POINT { x: pt.x, y: pt.y };
        unsafe {
            *pdweffect = DROPEFFECT_COPY;
            self.0
                .drop_target_helper
                .DragOver(&cursor_position, *pdweffect)
                .log_err();
            ScreenToClient(self.0.hwnd, &mut cursor_position)
                .ok()
                .log_err();
        }
        let scale_factor = self.0.state.borrow().scale_factor;
        let input = PlatformInput::FileDrop(FileDropEvent::Pending {
            position: logical_point(
                cursor_position.x as f32,
                cursor_position.y as f32,
                scale_factor,
            ),
        });
        self.handle_drag_drop(input);

        Ok(())
    }

    fn DragLeave(&self) -> windows::core::Result<()> {
        unsafe {
            self.0.drop_target_helper.DragLeave().log_err();
        }
        let input = PlatformInput::FileDrop(FileDropEvent::Exited);
        self.handle_drag_drop(input);

        Ok(())
    }

    fn Drop(
        &self,
        pdataobj: windows::core::Ref<IDataObject>,
        _grfkeystate: MODIFIERKEYS_FLAGS,
        pt: &POINTL,
        pdweffect: *mut DROPEFFECT,
    ) -> windows::core::Result<()> {
        let idata_obj = pdataobj.ok()?;
        let mut cursor_position = POINT { x: pt.x, y: pt.y };
        unsafe {
            *pdweffect = DROPEFFECT_COPY;
            self.0
                .drop_target_helper
                .Drop(idata_obj, &cursor_position, *pdweffect)
                .log_err();
            ScreenToClient(self.0.hwnd, &mut cursor_position)
                .ok()
                .log_err();
        }
        let scale_factor = self.0.state.borrow().scale_factor;
        let input = PlatformInput::FileDrop(FileDropEvent::Submit {
            position: logical_point(
                cursor_position.x as f32,
                cursor_position.y as f32,
                scale_factor,
            ),
        });
        self.handle_drag_drop(input);

        Ok(())
    }
}

fn external_drop_data_from_data_object(idata_obj: &IDataObject) -> Option<ExternalDropData> {
    let mut paths = SmallVec::<[PathBuf; 2]>::new();

    if let Some(mut idata) = data_object_get_hglobal(idata_obj, CF_HDROP.0) {
        let hglobal = unsafe { idata.u.hGlobal };
        if !hglobal.is_invalid() {
            let hdrop = hglobal.0 as *mut HDROP;
            unsafe {
                with_file_names(*hdrop, |file_name| {
                    if let Some(path) = PathBuf::from_str(&file_name).log_err() {
                        paths.push(path);
                    }
                });
            }
        }
        unsafe {
            ReleaseStgMedium(&mut idata);
        }
    }

    let text = data_object_unicode_text(idata_obj);
    let mut data = ExternalDropData::from_paths(paths);
    if let Some(text) = text {
        let parsed_text = ExternalDropData::from_plain_text(text.clone());
        data = data
            .with_text(text)
            .with_urls(parsed_text.urls().iter().cloned());
    }

    if data.has_paths() || data.has_text() || data.has_urls() {
        Some(data)
    } else {
        None
    }
}

fn data_object_get_hglobal(idata_obj: &IDataObject, clipboard_format: u16) -> Option<STGMEDIUM> {
    let config = FORMATETC {
        cfFormat: clipboard_format,
        ptd: std::ptr::null_mut() as _,
        dwAspect: DVASPECT_CONTENT.0,
        lindex: -1,
        tymed: TYMED_HGLOBAL.0 as _,
    };
    unsafe {
        if idata_obj.QueryGetData(&config as _) != S_OK {
            return None;
        }
        idata_obj.GetData(&config as _).log_err()
    }
}

fn data_object_unicode_text(idata_obj: &IDataObject) -> Option<String> {
    let mut idata = data_object_get_hglobal(idata_obj, CF_UNICODETEXT.0)?;
    let hglobal = unsafe { idata.u.hGlobal };
    let text = if hglobal.is_invalid() {
        None
    } else {
        unsafe { hglobal_utf16_string(hglobal) }
    };
    unsafe {
        ReleaseStgMedium(&mut idata);
    }
    text.filter(|text| !text.is_empty())
}

unsafe fn hglobal_utf16_string(hglobal: HGLOBAL) -> Option<String> {
    let ptr = unsafe { GlobalLock(hglobal) } as *const u16;
    if ptr.is_null() {
        return None;
    }
    let _lock = GlobalMemoryLock(hglobal);
    let byte_len = unsafe { GlobalSize(hglobal) };
    if byte_len == 0 || byte_len > MAX_NATIVE_TEXT_BYTES {
        log::warn!("rejecting invalid or oversized Windows global-memory text ({byte_len} bytes)");
        return None;
    }
    let units = byte_len / std::mem::size_of::<u16>();
    let allocation = unsafe { std::slice::from_raw_parts(ptr, units) };
    let len = allocation.iter().position(|unit| *unit == 0)?;
    String::from_utf16(&allocation[..len]).ok()
}

fn file_drop_entered_event(position: Point<Pixels>, data: ExternalDropData) -> PlatformInput {
    if data.has_urls() || data.has_text() {
        PlatformInput::FileDrop(FileDropEvent::DataEntered { position, data })
    } else {
        PlatformInput::FileDrop(FileDropEvent::Entered {
            position,
            paths: data.paths().clone(),
        })
    }
}

#[derive(Debug, Clone, Copy)]
pub(crate) struct ClickState {
    button: MouseButton,
    last_click: Instant,
    last_position: Point<DevicePixels>,
    double_click_spatial_tolerance_width: i32,
    double_click_spatial_tolerance_height: i32,
    double_click_interval: Duration,
    pub(crate) current_count: usize,
}

impl ClickState {
    pub fn new() -> Self {
        let double_click_spatial_tolerance_width = unsafe { GetSystemMetrics(SM_CXDOUBLECLK) };
        let double_click_spatial_tolerance_height = unsafe { GetSystemMetrics(SM_CYDOUBLECLK) };
        let double_click_interval = Duration::from_millis(unsafe { GetDoubleClickTime() } as u64);

        ClickState {
            button: MouseButton::Left,
            last_click: Instant::now(),
            last_position: Point::default(),
            double_click_spatial_tolerance_width,
            double_click_spatial_tolerance_height,
            double_click_interval,
            current_count: 0,
        }
    }

    /// update self and return the needed click count
    pub fn update(&mut self, button: MouseButton, new_position: Point<DevicePixels>) -> usize {
        if self.button == button && self.is_double_click(new_position) {
            self.current_count += 1;
        } else {
            self.current_count = 1;
        }
        self.last_click = Instant::now();
        self.last_position = new_position;
        self.button = button;

        self.current_count
    }

    pub fn system_update(&mut self, wparam: usize) {
        match wparam {
            // SPI_SETDOUBLECLKWIDTH
            29 => {
                self.double_click_spatial_tolerance_width =
                    unsafe { GetSystemMetrics(SM_CXDOUBLECLK) }
            }
            // SPI_SETDOUBLECLKHEIGHT
            30 => {
                self.double_click_spatial_tolerance_height =
                    unsafe { GetSystemMetrics(SM_CYDOUBLECLK) }
            }
            // SPI_SETDOUBLECLICKTIME
            32 => {
                self.double_click_interval =
                    Duration::from_millis(unsafe { GetDoubleClickTime() } as u64)
            }
            _ => {}
        }
    }

    #[inline]
    fn is_double_click(&self, new_position: Point<DevicePixels>) -> bool {
        let diff = self.last_position - new_position;

        self.last_click.elapsed() < self.double_click_interval
            && diff.x.0.abs() <= self.double_click_spatial_tolerance_width
            && diff.y.0.abs() <= self.double_click_spatial_tolerance_height
    }
}

struct StyleAndBounds {
    style: WINDOW_STYLE,
    x: i32,
    y: i32,
    cx: i32,
    cy: i32,
}

#[repr(C)]
struct WINDOWCOMPOSITIONATTRIBDATA {
    attrib: u32,
    pv_data: *mut std::ffi::c_void,
    cb_data: usize,
}

#[repr(C)]
struct AccentPolicy {
    accent_state: u32,
    accent_flags: u32,
    gradient_color: u32,
    animation_id: u32,
}

type Color = (u8, u8, u8, u8);

#[derive(Debug, Default, Clone, Copy)]
pub(crate) struct WindowBorderOffset {
    pub(crate) width_offset: i32,
    pub(crate) height_offset: i32,
}

impl WindowBorderOffset {
    pub(crate) fn update(&mut self, hwnd: HWND) -> anyhow::Result<()> {
        let window_rect = unsafe {
            let mut rect = std::mem::zeroed();
            GetWindowRect(hwnd, &mut rect)?;
            rect
        };
        let client_rect = unsafe {
            let mut rect = std::mem::zeroed();
            GetClientRect(hwnd, &mut rect)?;
            rect
        };
        self.width_offset =
            (window_rect.right - window_rect.left) - (client_rect.right - client_rect.left);
        self.height_offset =
            (window_rect.bottom - window_rect.top) - (client_rect.bottom - client_rect.top);
        Ok(())
    }
}

struct WindowOpenStatus {
    placement: WINDOWPLACEMENT,
    state: WindowOpenState,
}

enum WindowOpenState {
    Maximized,
    Fullscreen,
    Windowed,
}

const WINDOW_CLASS_NAME: PCWSTR = w!("Kael::Window");

fn register_window_class(icon_handle: HICON) -> Result<()> {
    static REGISTRATION: OnceLock<std::result::Result<(), String>> = OnceLock::new();
    REGISTRATION
        .get_or_init(|| {
            let hinstance = get_module_handle().map_err(|error| error.to_string())?;
            let wc = WNDCLASSW {
                lpfnWndProc: Some(window_procedure),
                hIcon: icon_handle,
                lpszClassName: PCWSTR(WINDOW_CLASS_NAME.as_ptr()),
                style: CS_HREDRAW | CS_VREDRAW,
                hInstance: hinstance.into(),
                hbrBackground: unsafe { CreateSolidBrush(COLORREF(0x00000000)) },
                ..Default::default()
            };
            let atom = unsafe { RegisterClassW(&wc) };
            if atom == 0 {
                return Err(windows::core::Error::from_thread().to_string());
            }
            Ok(())
        })
        .as_ref()
        .map_err(|error| anyhow::anyhow!("unable to register window class: {error}"))
        .copied()
}

unsafe extern "system" fn window_procedure(
    hwnd: HWND,
    msg: u32,
    wparam: WPARAM,
    lparam: LPARAM,
) -> LRESULT {
    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| unsafe {
        window_procedure_impl(hwnd, msg, wparam, lparam)
    })) {
        Ok(result) => result,
        Err(_) => {
            log::error!("window procedure panicked; containing panic at the Windows ABI boundary");
            if msg == WM_NCDESTROY {
                let ptr = unsafe { get_window_long(hwnd, GWLP_USERDATA) }
                    as *mut Weak<WindowsWindowInner>;
                if !ptr.is_null() {
                    unsafe { set_window_long(hwnd, GWLP_USERDATA, 0) };
                    unsafe { drop(Box::from_raw(ptr)) };
                }
            }
            LRESULT(0)
        }
    }
}

unsafe fn window_procedure_impl(hwnd: HWND, msg: u32, wparam: WPARAM, lparam: LPARAM) -> LRESULT {
    if msg == WM_NCCREATE {
        let window_params = lparam.0 as *const CREATESTRUCTW;
        if window_params.is_null() {
            return LRESULT(0);
        }
        let window_params = unsafe { &*window_params };
        let window_creation_context = window_params.lpCreateParams as *mut WindowCreateContext;
        if window_creation_context.is_null() {
            return LRESULT(0);
        }
        let window_creation_context = unsafe { &mut *window_creation_context };
        return match WindowsWindowInner::new(window_creation_context, hwnd, window_params) {
            Ok(window_state) => {
                let weak = Box::new(Rc::downgrade(&window_state));
                unsafe { set_window_long(hwnd, GWLP_USERDATA, Box::into_raw(weak) as isize) };
                window_creation_context.inner = Some(Ok(window_state));
                unsafe { DefWindowProcW(hwnd, msg, wparam, lparam) }
            }
            Err(error) => {
                window_creation_context.inner = Some(Err(error));
                LRESULT(0)
            }
        };
    }

    let ptr = unsafe { get_window_long(hwnd, GWLP_USERDATA) } as *mut Weak<WindowsWindowInner>;
    if ptr.is_null() {
        return unsafe { DefWindowProcW(hwnd, msg, wparam, lparam) };
    }
    let inner = unsafe { &*ptr };
    let result = if let Some(inner) = inner.upgrade() {
        inner.handle_msg(hwnd, msg, wparam, lparam)
    } else {
        unsafe { DefWindowProcW(hwnd, msg, wparam, lparam) }
    };

    if msg == WM_NCDESTROY {
        unsafe { set_window_long(hwnd, GWLP_USERDATA, 0) };
        unsafe { drop(Box::from_raw(ptr)) };
    }

    result
}

pub(crate) fn window_from_hwnd(hwnd: HWND) -> Option<Rc<WindowsWindowInner>> {
    if hwnd.is_invalid() {
        return None;
    }

    let ptr = unsafe { get_window_long(hwnd, GWLP_USERDATA) } as *mut Weak<WindowsWindowInner>;
    if !ptr.is_null() {
        let inner = unsafe { &*ptr };
        inner.upgrade()
    } else {
        None
    }
}

fn get_module_handle() -> Result<HMODULE> {
    unsafe {
        let mut h_module = std::mem::zeroed();
        GetModuleHandleExW(
            GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            windows::core::w!("ZedModule"),
            &mut h_module,
        )
        .context("unable to get module handle")?;

        Ok(h_module)
    }
}

fn register_drag_drop(window: &Rc<WindowsWindowInner>) -> Result<()> {
    let window_handle = window.hwnd;
    let handler = WindowsDragDropHandler(window.clone());
    // The lifetime of `IDropTarget` is handled by Windows, it won't release until
    // we call `RevokeDragDrop`.
    // So, it's safe to drop it here.
    let drag_drop_handler: IDropTarget = handler.into();
    unsafe {
        RegisterDragDrop(window_handle, &drag_drop_handler)
            .context("unable to register drag-drop event")?;
    }
    Ok(())
}

fn calculate_window_rect(bounds: Bounds<DevicePixels>, border_offset: WindowBorderOffset) -> RECT {
    // NOTE:
    // The reason we're not using `AdjustWindowRectEx()` here is
    // that the size reported by this function is incorrect.
    // You can test it, and there are similar discussions online.
    // See: https://stackoverflow.com/questions/12423584/how-to-set-exact-client-size-for-overlapped-window-winapi
    //
    // So we manually calculate these values here.
    let mut rect = RECT {
        left: bounds.left().0,
        top: bounds.top().0,
        right: bounds.right().0,
        bottom: bounds.bottom().0,
    };
    let left_offset = border_offset.width_offset / 2;
    let top_offset = border_offset.height_offset / 2;
    let right_offset = border_offset.width_offset - left_offset;
    let bottom_offset = border_offset.height_offset - top_offset;
    rect.left -= left_offset;
    rect.top -= top_offset;
    rect.right += right_offset;
    rect.bottom += bottom_offset;
    rect
}

fn calculate_client_rect(
    rect: RECT,
    border_offset: WindowBorderOffset,
    scale_factor: f32,
) -> Bounds<Pixels> {
    let left_offset = border_offset.width_offset / 2;
    let top_offset = border_offset.height_offset / 2;
    let right_offset = border_offset.width_offset - left_offset;
    let bottom_offset = border_offset.height_offset - top_offset;
    let left = rect.left + left_offset;
    let top = rect.top + top_offset;
    let right = rect.right - right_offset;
    let bottom = rect.bottom - bottom_offset;
    let physical_size = size(DevicePixels(right - left), DevicePixels(bottom - top));
    Bounds {
        origin: logical_point(left as f32, top as f32, scale_factor),
        size: physical_size.to_pixels(scale_factor),
    }
}

fn retrieve_window_placement(
    hwnd: HWND,
    display: WindowsDisplay,
    initial_bounds: Bounds<Pixels>,
    scale_factor: f32,
    border_offset: WindowBorderOffset,
) -> Result<WINDOWPLACEMENT> {
    let mut placement = WINDOWPLACEMENT {
        length: std::mem::size_of::<WINDOWPLACEMENT>() as u32,
        ..Default::default()
    };
    unsafe { GetWindowPlacement(hwnd, &mut placement)? };
    // the bounds may be not inside the display
    let bounds = if display.check_given_bounds(initial_bounds) {
        initial_bounds
    } else {
        display.default_bounds()
    };
    let bounds = bounds.to_device_pixels(scale_factor);
    placement.rcNormalPosition = calculate_window_rect(bounds, border_offset);
    Ok(placement)
}

fn set_window_composition_attribute(hwnd: HWND, color: Option<Color>, state: u32) {
    let mut version = unsafe { std::mem::zeroed() };
    let status = unsafe { windows::Wdk::System::SystemServices::RtlGetVersion(&mut version) };
    if !status.is_ok() || version.dwBuildNumber < 17763 {
        return;
    }

    unsafe {
        type SetWindowCompositionAttributeType =
            unsafe extern "system" fn(HWND, *mut WINDOWCOMPOSITIONATTRIBDATA) -> BOOL;
        let module_name = PCSTR::from_raw(c"user32.dll".as_ptr() as *const u8);
        if let Some(user32) = GetModuleHandleA(module_name)
            .context("Unable to get user32.dll handle")
            .log_err()
        {
            let func_name = PCSTR::from_raw(c"SetWindowCompositionAttribute".as_ptr() as *const u8);
            let set_window_composition_attribute: SetWindowCompositionAttributeType =
                std::mem::transmute(GetProcAddress(user32, func_name));
            let mut color = color.unwrap_or_default();
            let is_acrylic = state == 4;
            if is_acrylic && color.3 == 0 {
                color.3 = 1;
            }
            let accent = AccentPolicy {
                accent_state: state,
                accent_flags: if is_acrylic { 0 } else { 2 },
                gradient_color: (color.0 as u32)
                    | ((color.1 as u32) << 8)
                    | ((color.2 as u32) << 16)
                    | ((color.3 as u32) << 24),
                animation_id: 0,
            };
            let mut data = WINDOWCOMPOSITIONATTRIBDATA {
                attrib: 0x13,
                pv_data: &accent as *const _ as *mut _,
                cb_data: std::mem::size_of::<AccentPolicy>(),
            };
            let _ = set_window_composition_attribute(hwnd, &mut data as *mut _ as _);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::ClickState;
    use crate::{DevicePixels, MouseButton, point};
    use std::time::Duration;

    #[test]
    fn test_double_click_interval() {
        let mut state = ClickState::new();
        assert_eq!(
            state.update(MouseButton::Left, point(DevicePixels(0), DevicePixels(0))),
            1
        );
        assert_eq!(
            state.update(MouseButton::Right, point(DevicePixels(0), DevicePixels(0))),
            1
        );
        assert_eq!(
            state.update(MouseButton::Left, point(DevicePixels(0), DevicePixels(0))),
            1
        );
        assert_eq!(
            state.update(MouseButton::Left, point(DevicePixels(0), DevicePixels(0))),
            2
        );
        state.last_click -= Duration::from_millis(700);
        assert_eq!(
            state.update(MouseButton::Left, point(DevicePixels(0), DevicePixels(0))),
            1
        );
    }

    #[test]
    fn test_double_click_spatial_tolerance() {
        let mut state = ClickState::new();
        assert_eq!(
            state.update(MouseButton::Left, point(DevicePixels(-3), DevicePixels(0))),
            1
        );
        assert_eq!(
            state.update(MouseButton::Left, point(DevicePixels(0), DevicePixels(3))),
            2
        );
        assert_eq!(
            state.update(MouseButton::Right, point(DevicePixels(3), DevicePixels(2))),
            1
        );
        assert_eq!(
            state.update(MouseButton::Right, point(DevicePixels(10), DevicePixels(0))),
            1
        );
    }
}
