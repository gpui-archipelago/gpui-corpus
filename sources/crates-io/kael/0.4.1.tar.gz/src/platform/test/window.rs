use crate::{
    AnyWindowHandle, AtlasKey, AtlasTextureId, AtlasTile, Bounds, DispatchEventResult, GpuSpecs,
    Pixels, PlatformAtlas, PlatformDisplay, PlatformInput, PlatformInputHandler, PlatformWindow,
    Point, PromptButton, RequestFrameOptions, Size, TestPlatform, TileId, WindowAppearance,
    WindowBackgroundAppearance, WindowBounds, WindowControlArea, WindowParams,
};
use collections::HashMap;
use parking_lot::Mutex;
use raw_window_handle::{HasDisplayHandle, HasWindowHandle};
use std::{
    rc::{Rc, Weak},
    sync::{self, Arc},
};

pub(crate) struct TestWindowState {
    pub(crate) bounds: Bounds<Pixels>,
    scale_factor: f32,
    pub(crate) handle: AnyWindowHandle,
    display: Rc<dyn PlatformDisplay>,
    pub(crate) title: Option<String>,
    pub(crate) edited: bool,
    platform: Weak<TestPlatform>,
    sprite_atlas: Arc<dyn PlatformAtlas>,
    pub(crate) should_close_handler: Option<Box<dyn FnMut() -> bool>>,
    request_frame_callback: Option<Box<dyn FnMut(RequestFrameOptions)>>,
    hit_test_window_control_callback: Option<Box<dyn FnMut() -> Option<WindowControlArea>>>,
    input_callback: Option<Box<dyn FnMut(PlatformInput) -> DispatchEventResult>>,
    active_status_change_callback: Option<Box<dyn FnMut(bool)>>,
    hover_status_change_callback: Option<Box<dyn FnMut(bool)>>,
    resize_callback: Option<Box<dyn FnMut(Size<Pixels>, f32)>>,
    moved_callback: Option<Box<dyn FnMut()>>,
    input_handler: Option<PlatformInputHandler>,
    is_fullscreen: bool,
    pub(crate) opacity: f32,
    pub(crate) always_on_top: bool,
    pub(crate) frame_polling_active: bool,
    pub(crate) close_requested: bool,
    pub(crate) accessibility_tree: Option<crate::AccessibilityTree>,
}

#[derive(Clone)]
pub(crate) struct TestWindow(pub(crate) Rc<Mutex<TestWindowState>>);

impl HasWindowHandle for TestWindow {
    fn window_handle(
        &self,
    ) -> Result<raw_window_handle::WindowHandle<'_>, raw_window_handle::HandleError> {
        Err(raw_window_handle::HandleError::Unavailable)
    }
}

impl HasDisplayHandle for TestWindow {
    fn display_handle(
        &self,
    ) -> Result<raw_window_handle::DisplayHandle<'_>, raw_window_handle::HandleError> {
        Err(raw_window_handle::HandleError::Unavailable)
    }
}

impl TestWindow {
    pub fn new(
        handle: AnyWindowHandle,
        params: WindowParams,
        platform: Weak<TestPlatform>,
        display: Rc<dyn PlatformDisplay>,
    ) -> Self {
        let scale_factor = display.scale_factor();
        Self(Rc::new(Mutex::new(TestWindowState {
            bounds: params.bounds,
            scale_factor,
            display,
            platform,
            handle,
            sprite_atlas: Arc::new(TestAtlas::new()),
            title: Default::default(),
            edited: false,
            should_close_handler: None,
            request_frame_callback: None,
            hit_test_window_control_callback: None,
            input_callback: None,
            active_status_change_callback: None,
            hover_status_change_callback: None,
            resize_callback: None,
            moved_callback: None,
            input_handler: None,
            is_fullscreen: false,
            opacity: 1.0,
            always_on_top: false,
            frame_polling_active: false,
            close_requested: false,
            accessibility_tree: None,
        })))
    }

    pub fn simulate_resize(&mut self, size: Size<Pixels>) {
        let scale_factor = self.scale_factor();
        let mut lock = self.0.lock();
        let Some(mut callback) = lock.resize_callback.take() else {
            return;
        };
        lock.bounds.size = size;
        drop(lock);
        callback(size, scale_factor);
        self.0.lock().resize_callback = Some(callback);
    }

    /// Simulate moving a window to a display with a different backing scale.
    #[cfg(test)]
    pub fn simulate_backing_change(&mut self, scale_factor: f32) {
        assert!(scale_factor.is_finite() && scale_factor > 0.0);
        let mut lock = self.0.lock();
        lock.scale_factor = scale_factor;
        let size = lock.bounds.size;
        let Some(mut callback) = lock.resize_callback.take() else {
            return;
        };
        drop(lock);
        callback(size, scale_factor);
        self.0.lock().resize_callback = Some(callback);
    }

    pub(crate) fn simulate_active_status_change(&self, active: bool) {
        let mut lock = self.0.lock();
        let Some(mut callback) = lock.active_status_change_callback.take() else {
            return;
        };
        drop(lock);
        callback(active);
        self.0.lock().active_status_change_callback = Some(callback);
    }

    pub fn simulate_input(&mut self, event: PlatformInput) -> bool {
        let mut lock = self.0.lock();
        let Some(mut callback) = lock.input_callback.take() else {
            return false;
        };
        drop(lock);
        let result = callback(event);
        self.0.lock().input_callback = Some(callback);
        !result.propagate
    }

    #[allow(dead_code)]
    pub(crate) fn run_request_frame(&self, request_frame_options: RequestFrameOptions) {
        let mut lock = self.0.lock();
        let Some(mut callback) = lock.request_frame_callback.take() else {
            return;
        };
        drop(lock);
        callback(request_frame_options);
        self.0.lock().request_frame_callback = Some(callback);
    }
}

impl PlatformWindow for TestWindow {
    fn bounds(&self) -> Bounds<Pixels> {
        self.0.lock().bounds
    }

    fn window_bounds(&self) -> WindowBounds {
        WindowBounds::Windowed(self.bounds())
    }

    fn is_maximized(&self) -> bool {
        false
    }

    fn content_size(&self) -> Size<Pixels> {
        self.bounds().size
    }

    fn resize(&mut self, size: Size<Pixels>) {
        let mut lock = self.0.lock();
        lock.bounds.size = size;
    }

    fn scale_factor(&self) -> f32 {
        self.0.lock().scale_factor
    }

    fn appearance(&self) -> WindowAppearance {
        WindowAppearance::Light
    }

    fn display(&self) -> Option<std::rc::Rc<dyn crate::PlatformDisplay>> {
        Some(self.0.lock().display.clone())
    }

    fn mouse_position(&self) -> Point<Pixels> {
        Point::default()
    }

    fn modifiers(&self) -> crate::Modifiers {
        crate::Modifiers::default()
    }

    fn capslock(&self) -> crate::Capslock {
        crate::Capslock::default()
    }

    fn set_input_handler(&mut self, input_handler: PlatformInputHandler) {
        self.0.lock().input_handler = Some(input_handler);
    }

    fn take_input_handler(&mut self) -> Option<PlatformInputHandler> {
        self.0.lock().input_handler.take()
    }

    fn prompt(
        &self,
        _level: crate::PromptLevel,
        msg: &str,
        detail: Option<&str>,
        answers: &[PromptButton],
    ) -> Option<futures::channel::oneshot::Receiver<usize>> {
        Some(
            self.0
                .lock()
                .platform
                .upgrade()
                .expect("platform dropped")
                .prompt(msg, detail, answers),
        )
    }

    fn activate(&self) {
        self.0
            .lock()
            .platform
            .upgrade()
            .unwrap()
            .set_active_window(Some(self.clone()))
    }

    fn is_active(&self) -> bool {
        false
    }

    fn is_hovered(&self) -> bool {
        false
    }

    fn set_title(&mut self, title: &str) {
        self.0.lock().title = Some(title.to_owned());
    }

    fn set_app_id(&mut self, _app_id: &str) {}

    fn set_background_appearance(&self, _background: WindowBackgroundAppearance) {}

    fn set_opacity(&self, opacity: f32) {
        self.0.lock().opacity = opacity;
    }

    fn set_always_on_top(&self, always_on_top: bool) {
        self.0.lock().always_on_top = always_on_top;
    }

    fn set_edited(&mut self, edited: bool) {
        self.0.lock().edited = edited;
    }

    fn show_character_palette(&self) {}

    fn minimize(&self) {}

    fn zoom(&self) {}

    fn toggle_fullscreen(&self) {
        let mut lock = self.0.lock();
        lock.is_fullscreen = !lock.is_fullscreen;
    }

    fn is_fullscreen(&self) -> bool {
        self.0.lock().is_fullscreen
    }

    fn on_request_frame(&self, callback: Box<dyn FnMut(RequestFrameOptions)>) {
        self.0.lock().request_frame_callback = Some(callback);
    }

    fn set_frame_polling(&self, active: bool) {
        self.0.lock().frame_polling_active = active;
    }

    fn close(&self) {
        let mut state = self.0.lock();
        let should_close = if let Some(callback) = state.should_close_handler.as_mut() {
            callback()
        } else {
            true
        };
        if should_close {
            state.close_requested = true;
        }
    }

    fn on_input(&self, callback: Box<dyn FnMut(crate::PlatformInput) -> DispatchEventResult>) {
        self.0.lock().input_callback = Some(callback)
    }

    fn on_active_status_change(&self, callback: Box<dyn FnMut(bool)>) {
        self.0.lock().active_status_change_callback = Some(callback)
    }

    fn on_hover_status_change(&self, callback: Box<dyn FnMut(bool)>) {
        self.0.lock().hover_status_change_callback = Some(callback)
    }

    fn on_resize(&self, callback: Box<dyn FnMut(Size<Pixels>, f32)>) {
        self.0.lock().resize_callback = Some(callback)
    }

    fn on_moved(&self, callback: Box<dyn FnMut()>) {
        self.0.lock().moved_callback = Some(callback)
    }

    fn on_should_close(&self, callback: Box<dyn FnMut() -> bool>) {
        self.0.lock().should_close_handler = Some(callback);
    }

    fn on_close(&self, _callback: Box<dyn FnOnce()>) {}

    fn on_hit_test_window_control(&self, callback: Box<dyn FnMut() -> Option<WindowControlArea>>) {
        self.0.lock().hit_test_window_control_callback = Some(callback);
    }

    fn on_appearance_changed(&self, _callback: Box<dyn FnMut()>) {}

    fn draw(&self, _scene: &crate::Scene) {}

    fn sprite_atlas(&self) -> sync::Arc<dyn crate::PlatformAtlas> {
        self.0.lock().sprite_atlas.clone()
    }

    fn as_test(&mut self) -> Option<&mut TestWindow> {
        Some(self)
    }

    #[cfg(target_os = "windows")]
    fn get_raw_handle(&self) -> windows::Win32::Foundation::HWND {
        windows::Win32::Foundation::HWND::default()
    }

    fn show_window_menu(&self, _position: Point<Pixels>) {}

    fn start_window_move(&self) {}

    fn update_ime_position(&self, _bounds: Bounds<Pixels>) {}

    fn gpu_specs(&self) -> Option<GpuSpecs> {
        None
    }

    fn update_accessibility_tree(
        &mut self,
        tree: &crate::AccessibilityTree,
    ) -> Vec<crate::AccessibilityActionRequest> {
        self.0.lock().accessibility_tree = Some(tree.clone());
        Vec::new()
    }
}

pub(crate) struct TestAtlasState {
    next_id: u32,
    tiles: HashMap<AtlasKey, AtlasTile>,
}

pub(crate) struct TestAtlas(Mutex<TestAtlasState>);

impl TestAtlas {
    pub fn new() -> Self {
        TestAtlas(Mutex::new(TestAtlasState {
            next_id: 0,
            tiles: HashMap::default(),
        }))
    }
}

impl PlatformAtlas for TestAtlas {
    fn get_or_insert_with<'a>(
        &self,
        key: &crate::AtlasKey,
        build: &mut dyn FnMut() -> anyhow::Result<
            Option<(Size<crate::DevicePixels>, std::borrow::Cow<'a, [u8]>)>,
        >,
    ) -> anyhow::Result<Option<crate::AtlasTile>> {
        let mut state = self.0.lock();
        if let Some(tile) = state.tiles.get(key) {
            return Ok(Some(tile.clone()));
        }
        drop(state);

        let Some((size, _)) = build()? else {
            return Ok(None);
        };

        let mut state = self.0.lock();
        state.next_id += 1;
        let texture_id = state.next_id;
        state.next_id += 1;
        let tile_id = state.next_id;

        state.tiles.insert(
            key.clone(),
            crate::AtlasTile {
                texture_id: AtlasTextureId {
                    index: texture_id,
                    kind: key.texture_kind(),
                },
                tile_id: TileId(tile_id),
                padding: 0,
                bounds: crate::Bounds {
                    origin: Point::default(),
                    size,
                },
            },
        );

        Ok(Some(state.tiles[key].clone()))
    }

    fn remove(&self, key: &AtlasKey) {
        let mut state = self.0.lock();
        state.tiles.remove(key);
    }
}

#[cfg(test)]
mod tests {
    use crate::{
        Context, Empty, IntoElement, Render, RequestFrameOptions, TestAppContext, VisualContext,
        Window, WindowInteractionCommand, canvas_with_prepaint,
    };
    use raw_window_handle::{HandleError, HasDisplayHandle, HasWindowHandle};
    use std::{cell::Cell, rc::Rc};

    struct AnimationFrameRequester {
        requested: Rc<Cell<bool>>,
    }

    impl Render for AnimationFrameRequester {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
            let requested = self.requested.clone();
            canvas_with_prepaint(
                move |_, window, _| {
                    if !requested.replace(true) {
                        for _ in 0..100 {
                            window.request_animation_frame();
                        }
                    }
                },
                |_, _, _, _| {},
            )
        }
    }

    #[kael::test]
    fn request_frames_stop_polling_when_a_test_window_goes_idle(cx: &mut TestAppContext) {
        let (_view, cx) = cx.add_window_view(|_, _| Empty);
        let handle = cx.window_handle();
        let test_window = cx.test_window(handle);

        assert!(!test_window.0.lock().frame_polling_active);

        cx.update(|window, _| {
            window.on_next_frame(|_, _| {});
        });

        assert!(test_window.0.lock().frame_polling_active);

        test_window.run_request_frame(RequestFrameOptions::default());

        assert!(!test_window.0.lock().frame_polling_active);
    }

    #[kael::test]
    fn animation_frame_requests_are_coalesced_per_view(cx: &mut TestAppContext) {
        let requested = Rc::new(Cell::new(false));
        let (_view, cx) = cx.add_window_view({
            let requested = requested.clone();
            move |_, _| AnimationFrameRequester { requested }
        });
        let handle = cx.window_handle();
        let test_window = cx.test_window(handle);

        cx.update(|window, cx| {
            window.draw(cx).clear();
            assert_eq!(window.pending_animation_frame_request_count(), 1);
        });

        test_window.run_request_frame(RequestFrameOptions::default());
        cx.update(|window, _| {
            assert_eq!(window.pending_animation_frame_request_count(), 0);
        });
    }

    #[kael::test]
    fn checked_window_close_command_reaches_test_window(cx: &mut TestAppContext) {
        let (_view, cx) = cx.add_window_view(|_, _| Empty);
        let handle = cx.window_handle();
        let test_window = cx.test_window(handle);

        cx.update(|window, _| {
            window
                .perform_window_interaction_checked(WindowInteractionCommand::close(
                    "User clicked close",
                ))
                .unwrap();
        });

        assert!(test_window.0.lock().close_requested);
    }

    #[kael::test]
    fn test_windows_report_unavailable_raw_handles(cx: &mut TestAppContext) {
        let (_view, cx) = cx.add_window_view(|_, _| Empty);
        let handle = cx.window_handle();
        let test_window = cx.test_window(handle);

        assert!(matches!(
            test_window.window_handle(),
            Err(HandleError::Unavailable)
        ));
        assert!(matches!(
            test_window.display_handle(),
            Err(HandleError::Unavailable)
        ));
    }

    #[kael::test]
    fn backing_scale_changes_reach_the_framework_window(cx: &mut TestAppContext) {
        let (_view, cx) = cx.add_window_view(|_, _| Empty);
        let handle = cx.window_handle();
        let mut test_window = cx.test_window(handle);

        assert_eq!(cx.update(|window, _| window.scale_factor()), 2.0);
        test_window.simulate_backing_change(1.0);
        assert_eq!(cx.update(|window, _| window.scale_factor()), 1.0);
        test_window.simulate_backing_change(2.0);
        assert_eq!(cx.update(|window, _| window.scale_factor()), 2.0);
    }
}
