use std::{rc::Rc, time::Duration};

use crate::Styled;

/// An animation that can be applied to an element.
#[derive(Clone)]
pub struct Animation {
    duration: Duration,
    easing: Easing,
    delay: Duration,
    repeat: Repeat,
}

impl Animation {
    /// Creates a new animation with the given duration.
    pub fn new(duration: Duration) -> Self {
        Self {
            duration,
            easing: Easing::Linear,
            delay: Duration::ZERO,
            repeat: Repeat::Once,
        }
    }

    /// Sets the easing used by this animation.
    pub fn easing(mut self, easing: Easing) -> Self {
        self.easing = easing;
        self
    }

    /// Sets a custom easing function for this animation.
    pub fn with_easing(mut self, easing: impl Fn(f32) -> f32 + 'static) -> Self {
        self.easing = Easing::Custom(Rc::new(easing));
        self
    }

    /// Delays this animation relative to the start of its sequence.
    pub fn delay(mut self, delay: Duration) -> Self {
        self.delay = delay;
        self
    }

    /// Delays this animation by `index * step`, for staggering a list or grid so its
    /// elements animate in sequence instead of all at once.
    pub fn stagger(self, index: usize, step: Duration) -> Self {
        self.delay(step.saturating_mul(index as u32))
    }

    /// Sets the repeat behavior for this animation.
    pub fn repeat(mut self, repeat: Repeat) -> Self {
        self.repeat = repeat;
        self
    }

    /// Repeats this animation forever.
    pub fn repeat_forever(self) -> Self {
        self.repeat(Repeat::Forever)
    }

    /// Returns the active duration of one animation cycle.
    pub fn duration(&self) -> Duration {
        self.duration
    }

    /// Returns the delay before this animation starts.
    pub fn delay_duration(&self) -> Duration {
        self.delay
    }

    /// Returns true when this animation has a non-zero delay.
    pub fn has_delay(&self) -> bool {
        !self.delay.is_zero()
    }

    /// Returns the configured easing curve.
    pub fn easing_curve(&self) -> &Easing {
        &self.easing
    }

    /// Returns the configured repeat behavior.
    pub fn repeat_mode(&self) -> Repeat {
        self.repeat
    }

    /// Returns true when this animation can keep requesting frames indefinitely.
    pub fn repeats_forever(&self) -> bool {
        matches!(self.repeat, Repeat::Forever)
    }

    /// Returns the scheduled end including delay and finite repeats.
    pub fn scheduled_duration(&self) -> Duration {
        self.scheduled_end()
    }

    /// Returns a content-safe summary of the animation timeline.
    pub fn to_text(&self) -> String {
        format!(
            "animation: duration_ms {}, delay_ms {}, easing {}, repeat {}, scheduled_ms {}, forever {}",
            self.duration.as_millis(),
            self.delay.as_millis(),
            self.easing.to_text(),
            self.repeat.to_text(),
            self.scheduled_duration().as_millis(),
            self.repeats_forever()
        )
    }

    pub(crate) fn sample(&self, elapsed: Duration) -> AnimationSample {
        if elapsed < self.delay {
            return AnimationSample {
                delta: 0.0,
                started: false,
                finished: false,
            };
        }

        if self.duration.is_zero() {
            return AnimationSample {
                delta: 1.0,
                started: true,
                finished: self.repeat != Repeat::Forever,
            };
        }

        let local_elapsed = elapsed - self.delay;
        let local_seconds = local_elapsed.as_secs_f32();
        let duration_seconds = self.duration.as_secs_f32();

        match self.repeat {
            Repeat::Once => {
                let raw_delta = (local_seconds / duration_seconds).clamp(0.0, 1.0);
                AnimationSample {
                    delta: self.easing.sample(raw_delta),
                    started: true,
                    finished: raw_delta >= 1.0,
                }
            }
            Repeat::Count(count) => {
                let cycle_count = count.max(1);
                let total_seconds = duration_seconds * cycle_count as f32;
                if local_seconds >= total_seconds {
                    AnimationSample {
                        delta: 1.0,
                        started: true,
                        finished: true,
                    }
                } else {
                    AnimationSample {
                        delta: self
                            .easing
                            .sample((local_seconds / duration_seconds).fract()),
                        started: true,
                        finished: false,
                    }
                }
            }
            Repeat::Forever => AnimationSample {
                delta: self
                    .easing
                    .sample((local_seconds / duration_seconds).fract()),
                started: true,
                finished: false,
            },
        }
    }

    pub(crate) fn scheduled_end(&self) -> Duration {
        let active_duration = match self.repeat {
            Repeat::Once => self.duration,
            Repeat::Count(count) => self.duration.saturating_mul(count.max(1)),
            Repeat::Forever => self.duration,
        };

        self.delay + active_duration
    }
}

/// Supported easing curves for explicit animations.
///
/// This is the canonical easing vocabulary for the workspace. The `quad`
/// variants ([`Easing::EaseIn`], [`Easing::EaseOut`], [`Easing::EaseInOut`])
/// are quadratic; the cubic/quart/quint/expo/circ/back/elastic variants extend
/// the set with the standard CSS-style curves.
#[derive(Clone)]
pub enum Easing {
    /// A linear curve.
    Linear,
    /// A quadratic ease-in curve.
    EaseIn,
    /// A quadratic ease-out curve.
    EaseOut,
    /// A quadratic ease-in-out curve.
    EaseInOut,
    /// A cubic ease-in curve.
    EaseInCubic,
    /// A cubic ease-out curve (natural-feeling deceleration).
    EaseOutCubic,
    /// A cubic ease-in-out curve.
    EaseInOutCubic,
    /// A quartic ease-in curve.
    EaseInQuart,
    /// A quartic ease-out curve.
    EaseOutQuart,
    /// A quartic ease-in-out curve.
    EaseInOutQuart,
    /// A quintic ease-in curve.
    EaseInQuint,
    /// A quintic ease-out curve.
    EaseOutQuint,
    /// A quintic ease-in-out curve.
    EaseInOutQuint,
    /// An exponential ease-in curve.
    EaseInExpo,
    /// An exponential ease-out curve.
    EaseOutExpo,
    /// An exponential ease-in-out curve.
    EaseInOutExpo,
    /// A circular ease-in curve.
    EaseInCirc,
    /// A circular ease-out curve.
    EaseOutCirc,
    /// A circular ease-in-out curve.
    EaseInOutCirc,
    /// A backing ease-in curve with the given overshoot constant.
    EaseInBack(f32),
    /// A backing ease-out curve with the given overshoot constant.
    EaseOutBack(f32),
    /// A backing ease-in-out curve with the given overshoot constant.
    EaseInOutBack(f32),
    /// An elastic ease-in curve.
    EaseInElastic,
    /// An elastic ease-out curve.
    EaseOutElastic,
    /// A clamped elastic curve with a single decaying overshoot.
    Elastic,
    /// A stepped curve with the given number of discrete steps.
    Steps(u32),
    /// A cubic Bezier curve with CSS-style control points.
    CubicBezier(f32, f32, f32, f32),
    /// A custom easing callback.
    Custom(Rc<dyn Fn(f32) -> f32>),
}

impl Easing {
    pub(crate) fn sample(&self, delta: f32) -> f32 {
        use std::f32::consts::PI;
        let delta = delta.clamp(0.0, 1.0);

        match self {
            Self::Linear => easing::linear(delta),
            Self::EaseIn => easing::quadratic(delta),
            Self::EaseOut => easing::ease_out(delta),
            Self::EaseInOut => easing::ease_in_out(delta),
            Self::EaseInCubic => delta * delta * delta,
            Self::EaseOutCubic => {
                let t = delta - 1.0;
                t * t * t + 1.0
            }
            Self::EaseInOutCubic => {
                if delta < 0.5 {
                    4.0 * delta * delta * delta
                } else {
                    let t = 2.0 * delta - 2.0;
                    1.0 + t * t * t / 2.0
                }
            }
            Self::EaseInQuart => delta * delta * delta * delta,
            Self::EaseOutQuart => {
                let t = delta - 1.0;
                1.0 - t * t * t * t
            }
            Self::EaseInOutQuart => {
                if delta < 0.5 {
                    8.0 * delta * delta * delta * delta
                } else {
                    let t = delta - 1.0;
                    1.0 - 8.0 * t * t * t * t
                }
            }
            Self::EaseInQuint => delta * delta * delta * delta * delta,
            Self::EaseOutQuint => {
                let t = delta - 1.0;
                1.0 + t * t * t * t * t
            }
            Self::EaseInOutQuint => {
                if delta < 0.5 {
                    16.0 * delta * delta * delta * delta * delta
                } else {
                    let t = 2.0 * delta - 2.0;
                    1.0 + t * t * t * t * t / 2.0
                }
            }
            Self::EaseInExpo => {
                if delta == 0.0 {
                    0.0
                } else {
                    2_f32.powf(10.0 * delta - 10.0)
                }
            }
            Self::EaseOutExpo => {
                if delta >= 1.0 {
                    1.0
                } else {
                    1.0 - 2_f32.powf(-10.0 * delta)
                }
            }
            Self::EaseInOutExpo => {
                if delta == 0.0 {
                    0.0
                } else if delta >= 1.0 {
                    1.0
                } else if delta < 0.5 {
                    2_f32.powf(20.0 * delta - 10.0) / 2.0
                } else {
                    (2.0 - 2_f32.powf(-20.0 * delta + 10.0)) / 2.0
                }
            }
            Self::EaseInCirc => 1.0 - (1.0 - delta * delta).sqrt(),
            Self::EaseOutCirc => {
                let t = delta - 1.0;
                (1.0 - t * t).sqrt()
            }
            Self::EaseInOutCirc => {
                if delta < 0.5 {
                    (1.0 - (1.0 - (2.0 * delta).powi(2)).sqrt()) / 2.0
                } else {
                    ((1.0 - (-2.0 * delta + 2.0).powi(2)).sqrt() + 1.0) / 2.0
                }
            }
            Self::EaseInBack(overshoot) => {
                let c1 = *overshoot;
                let c3 = c1 + 1.0;
                (c3 * delta * delta * delta - c1 * delta * delta).max(0.0)
            }
            Self::EaseOutBack(overshoot) => {
                if delta >= 1.0 {
                    return 1.0;
                }
                let c1 = *overshoot;
                let c3 = c1 + 1.0;
                let t = delta - 1.0;
                (1.0 + c3 * t * t * t + c1 * t * t).clamp(0.0, 1.0)
            }
            Self::EaseInOutBack(overshoot) => {
                let c1 = *overshoot;
                let c2 = c1 * 1.525;
                if delta < 0.5 {
                    ((2.0 * delta).powi(2) * ((c2 + 1.0) * 2.0 * delta - c2)) / 2.0
                } else {
                    (((2.0 * delta - 2.0).powi(2) * ((c2 + 1.0) * (delta * 2.0 - 2.0) + c2) + 2.0)
                        / 2.0)
                        .clamp(0.0, 1.0)
                }
            }
            Self::EaseInElastic => {
                if delta == 0.0 {
                    return 0.0;
                }
                if delta >= 1.0 {
                    return 1.0;
                }
                let c4 = (2.0 * PI) / 3.0;
                (-(2_f32.powf(10.0 * delta - 10.0) * ((delta * 10.0 - 10.75) * c4).sin()))
                    .clamp(0.0, 1.0)
            }
            Self::EaseOutElastic => {
                if delta == 0.0 {
                    return 0.0;
                }
                if delta >= 1.0 {
                    return 1.0;
                }
                let c4 = (2.0 * PI) / 3.0;
                (2_f32.powf(-10.0 * delta) * ((delta * 10.0 - 0.75) * c4).sin() + 1.0)
                    .clamp(0.0, 1.0)
            }
            Self::Elastic => {
                if delta == 0.0 {
                    return 0.0;
                }
                if delta >= 1.0 {
                    return 1.0;
                }
                let p = 0.3;
                let s = p / 4.0;
                let t = delta - 1.0;
                (1.0 + (2_f32.powf(10.0 * t)) * ((t - s) * (2.0 * PI) / p).sin()).clamp(0.0, 1.0)
            }
            Self::Steps(count) => {
                let n = (*count).max(1) as f32;
                (delta * n).floor() / n
            }
            Self::CubicBezier(x1, y1, x2, y2) => cubic_bezier(*x1, *y1, *x2, *y2, delta),
            Self::Custom(callback) => callback(delta).clamp(0.0, 1.0),
        }
    }

    /// Sample this easing at `delta` in `0..=1` (public for media keyframes).
    pub fn ease(&self, delta: f32) -> f32 {
        self.sample(delta)
    }

    /// Returns a stable label for this easing curve without logging curve parameters.
    pub fn to_text(&self) -> &'static str {
        match self {
            Self::Linear => "linear",
            Self::EaseIn => "ease-in",
            Self::EaseOut => "ease-out",
            Self::EaseInOut => "ease-in-out",
            Self::EaseInCubic => "ease-in-cubic",
            Self::EaseOutCubic => "ease-out-cubic",
            Self::EaseInOutCubic => "ease-in-out-cubic",
            Self::EaseInQuart => "ease-in-quart",
            Self::EaseOutQuart => "ease-out-quart",
            Self::EaseInOutQuart => "ease-in-out-quart",
            Self::EaseInQuint => "ease-in-quint",
            Self::EaseOutQuint => "ease-out-quint",
            Self::EaseInOutQuint => "ease-in-out-quint",
            Self::EaseInExpo => "ease-in-expo",
            Self::EaseOutExpo => "ease-out-expo",
            Self::EaseInOutExpo => "ease-in-out-expo",
            Self::EaseInCirc => "ease-in-circ",
            Self::EaseOutCirc => "ease-out-circ",
            Self::EaseInOutCirc => "ease-in-out-circ",
            Self::EaseInBack(_) => "ease-in-back",
            Self::EaseOutBack(_) => "ease-out-back",
            Self::EaseInOutBack(_) => "ease-in-out-back",
            Self::EaseInElastic => "ease-in-elastic",
            Self::EaseOutElastic => "ease-out-elastic",
            Self::Elastic => "elastic",
            Self::Steps(_) => "steps",
            Self::CubicBezier(_, _, _, _) => "cubic-bezier",
            Self::Custom(_) => "custom",
        }
    }

    /// Returns true when this easing uses a caller-provided callback.
    pub fn is_custom(&self) -> bool {
        matches!(self, Self::Custom(_))
    }
}

/// How to interpolate from one media keyframe toward the next.
#[derive(Clone)]
pub enum KeyframeInterpolation {
    /// Hold the value until the next keyframe (step).
    Hold,
    /// Interpolate with the given easing curve (includes `CubicBezier` handles).
    Eased(Easing),
}

impl KeyframeInterpolation {
    /// Returns a stable label for this interpolation policy.
    pub fn to_text(&self) -> &'static str {
        match self {
            Self::Hold => "hold",
            Self::Eased(_) => "eased",
        }
    }
}

/// A single media keyframe: a value at a time, with the curve used to reach the
/// following keyframe.
#[derive(Clone)]
pub struct MediaKeyframe {
    /// Keyframe time, in seconds.
    pub time: f64,
    /// Keyframe value.
    pub value: f32,
    /// Interpolation toward the following keyframe.
    pub interpolation: KeyframeInterpolation,
}

impl MediaKeyframe {
    /// Returns a content-safe summary of this media keyframe.
    pub fn to_text(&self) -> String {
        format!(
            "media keyframe: interpolation {}, finite_time {}, finite_value {}",
            self.interpolation.to_text(),
            self.time.is_finite(),
            self.value.is_finite()
        )
    }
}

/// A keyframed scalar track sampled by the render/playback clock.
///
/// Generalizes the UI [`Keyframes`] machinery to media use — transform, opacity,
/// effect parameters, audio automation — reusing [`Easing`] (including
/// `CubicBezier` handles) for interpolation.
#[derive(Clone, Default)]
pub struct KeyframeTrack {
    keys: Vec<MediaKeyframe>,
}

impl KeyframeTrack {
    /// An empty track.
    pub fn new() -> Self {
        Self::default()
    }

    /// Insert a keyframe (kept sorted by time) and return the track.
    pub fn with_key(mut self, time: f64, value: f32, interpolation: KeyframeInterpolation) -> Self {
        self.insert(MediaKeyframe {
            time,
            value,
            interpolation,
        });
        self
    }

    /// Insert a keyframe, keeping the track sorted by time.
    pub fn insert(&mut self, key: MediaKeyframe) {
        let index = self
            .keys
            .partition_point(|existing| existing.time <= key.time);
        self.keys.insert(index, key);
    }

    /// Number of keyframes.
    pub fn len(&self) -> usize {
        self.keys.len()
    }

    /// Whether the track has no keyframes.
    pub fn is_empty(&self) -> bool {
        self.keys.is_empty()
    }

    /// Returns the number of hold keyframes in this track.
    pub fn hold_count(&self) -> usize {
        self.keys
            .iter()
            .filter(|key| matches!(key.interpolation, KeyframeInterpolation::Hold))
            .count()
    }

    /// Returns the number of eased keyframes in this track.
    pub fn eased_count(&self) -> usize {
        self.keys.len().saturating_sub(self.hold_count())
    }

    /// Returns true when all keyframe times and values are finite.
    pub fn is_finite(&self) -> bool {
        self.keys
            .iter()
            .all(|key| key.time.is_finite() && key.value.is_finite())
    }

    /// Returns a content-safe summary of this media keyframe track.
    pub fn to_text(&self) -> String {
        format!(
            "keyframe track: keys {}, hold {}, eased {}, finite {}, empty {}",
            self.len(),
            self.hold_count(),
            self.eased_count(),
            self.is_finite(),
            self.is_empty()
        )
    }

    /// Sample the track at `time` (seconds). Returns `default` for an empty
    /// track; clamps to the first/last value outside the keyframe range.
    pub fn sample(&self, time: f64, default: f32) -> f32 {
        let Some(first) = self.keys.first() else {
            return default;
        };
        if time <= first.time {
            return first.value;
        }
        let last = &self.keys[self.keys.len() - 1];
        if time >= last.time {
            return last.value;
        }
        let upper = self.keys.partition_point(|key| key.time <= time);
        let (k0, k1) = (&self.keys[upper - 1], &self.keys[upper]);
        match &k0.interpolation {
            KeyframeInterpolation::Hold => k0.value,
            KeyframeInterpolation::Eased(easing) => {
                let span = (k1.time - k0.time) as f32;
                let t = if span <= f32::EPSILON {
                    0.0
                } else {
                    ((time - k0.time) as f32 / span).clamp(0.0, 1.0)
                };
                k0.value + (k1.value - k0.value) * easing.ease(t)
            }
        }
    }
}

/// Repeat behavior for explicit animations.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Repeat {
    /// Play the animation once.
    Once,
    /// Play the animation a fixed number of times.
    Count(u32),
    /// Repeat the animation indefinitely.
    Forever,
}

impl Repeat {
    /// Returns a stable label for this repeat behavior.
    pub fn to_text(self) -> &'static str {
        match self {
            Self::Once => "once",
            Self::Count(_) => "count",
            Self::Forever => "forever",
        }
    }

    /// Returns the configured repeat count when this is [`Repeat::Count`].
    pub fn count(self) -> Option<u32> {
        match self {
            Self::Count(count) => Some(count),
            _ => None,
        }
    }

    /// Returns true when this repeat mode is indefinite.
    pub fn is_forever(self) -> bool {
        matches!(self, Self::Forever)
    }
}

/// A sequence of animations that can overlap with the previous step.
#[derive(Clone, Default)]
pub struct AnimationSequence {
    animations: Vec<Animation>,
}

impl AnimationSequence {
    /// Creates an empty animation sequence.
    pub fn new() -> Self {
        Self::default()
    }

    /// Appends an animation after the current sequence tail.
    pub fn then(mut self, animation: Animation) -> Self {
        let start = self
            .animations
            .iter()
            .map(Animation::scheduled_end)
            .max()
            .unwrap_or(Duration::ZERO);
        let delay = animation.delay;
        self.animations.push(animation.delay(start + delay));
        self
    }

    /// Appends a new animation with the given duration.
    pub fn then_for(self, duration: Duration) -> Self {
        self.then(Animation::new(duration))
    }

    /// Starts the most recently-added animation earlier so it overlaps the previous one.
    pub fn with_overlap(mut self, overlap: Duration) -> Self {
        if let Some(last) = self.animations.last_mut() {
            last.delay = last.delay.saturating_sub(overlap);
        }
        self
    }

    /// Consumes the sequence into its scheduled animations.
    pub fn into_animations(self) -> Vec<Animation> {
        self.animations
    }

    /// Returns the scheduled animations in this sequence.
    pub fn animations(&self) -> &[Animation] {
        &self.animations
    }

    /// Returns the number of animations in this sequence.
    pub fn len(&self) -> usize {
        self.animations.len()
    }

    /// Returns whether this sequence has no animations.
    pub fn is_empty(&self) -> bool {
        self.animations.is_empty()
    }

    /// Returns true when at least one animation in this sequence repeats forever.
    pub fn has_infinite_animation(&self) -> bool {
        self.animations
            .iter()
            .any(|animation| animation.repeats_forever())
    }

    /// Returns the scheduled end of the finite portion of this sequence.
    pub fn scheduled_duration(&self) -> Duration {
        self.animations
            .iter()
            .map(Animation::scheduled_end)
            .max()
            .unwrap_or(Duration::ZERO)
    }

    /// Returns a content-safe summary of this animation sequence.
    pub fn to_text(&self) -> String {
        format!(
            "animation sequence: animations {}, scheduled_ms {}, infinite {}, empty {}",
            self.len(),
            self.scheduled_duration().as_millis(),
            self.has_infinite_animation(),
            self.is_empty()
        )
    }
}

/// A set of keyframes that target common styled element properties.
#[derive(Clone, Default)]
pub struct Keyframes {
    frames: Vec<Keyframe>,
}

impl Keyframes {
    /// Creates an empty keyframe set.
    pub fn new() -> Self {
        Self::default()
    }

    /// Adds a keyframe at the given normalized time.
    pub fn at(
        mut self,
        progress: f32,
        build: impl FnOnce(StyledKeyframe) -> StyledKeyframe,
    ) -> Self {
        self.frames.push(Keyframe {
            progress: progress.clamp(0.0, 1.0),
            style: build(StyledKeyframe::default()),
        });
        self.frames
            .sort_by(|left, right| left.progress.total_cmp(&right.progress));
        self
    }

    pub(crate) fn sample(&self, progress: f32) -> StyledKeyframe {
        let progress = progress.clamp(0.0, 1.0);
        let Some(first) = self.frames.first() else {
            return StyledKeyframe::default();
        };

        if progress <= first.progress {
            return first.style;
        }

        for window in self.frames.windows(2) {
            let start = &window[0];
            let end = &window[1];
            if progress <= end.progress {
                let segment_delta = if (end.progress - start.progress).abs() <= f32::EPSILON {
                    1.0
                } else {
                    (progress - start.progress) / (end.progress - start.progress)
                };
                return start.style.interpolate(end.style, segment_delta);
            }
        }

        self.frames
            .last()
            .map(|frame| frame.style)
            .unwrap_or_default()
    }

    pub(crate) fn apply<E: Styled>(&self, element: E, progress: f32) -> E {
        self.sample(progress).apply(element)
    }

    /// Returns the number of configured keyframes.
    pub fn len(&self) -> usize {
        self.frames.len()
    }

    /// Returns whether this keyframe set has no frames.
    pub fn is_empty(&self) -> bool {
        self.frames.is_empty()
    }

    /// Returns how many keyframes set opacity.
    pub fn opacity_frame_count(&self) -> usize {
        self.frames
            .iter()
            .filter(|frame| frame.style.has_opacity())
            .count()
    }

    /// Returns how many keyframes set any transform property.
    pub fn transform_frame_count(&self) -> usize {
        self.frames
            .iter()
            .filter(|frame| frame.style.has_transform())
            .count()
    }

    /// Returns a content-safe summary of this keyframe set.
    pub fn to_text(&self) -> String {
        format!(
            "keyframes: frames {}, opacity_frames {}, transform_frames {}, empty {}",
            self.len(),
            self.opacity_frame_count(),
            self.transform_frame_count(),
            self.is_empty()
        )
    }
}

/// Creates a keyframe builder for explicit styled animations.
pub fn keyframes() -> Keyframes {
    Keyframes::new()
}

#[derive(Clone, Copy)]
struct Keyframe {
    progress: f32,
    style: StyledKeyframe,
}

/// A single styled keyframe.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct StyledKeyframe {
    opacity: Option<f32>,
    scale_x: Option<f32>,
    scale_y: Option<f32>,
    rotate_degrees: Option<f32>,
    translate_x: Option<f32>,
    translate_y: Option<f32>,
}

impl StyledKeyframe {
    /// Sets the target opacity.
    pub fn opacity(mut self, opacity: f32) -> Self {
        self.opacity = Some(opacity);
        self
    }

    /// Sets a uniform target scale.
    pub fn scale(mut self, factor: f32) -> Self {
        self.scale_x = Some(factor);
        self.scale_y = Some(factor);
        self
    }

    /// Sets a non-uniform target scale.
    pub fn scale_xy(mut self, x: f32, y: f32) -> Self {
        self.scale_x = Some(x);
        self.scale_y = Some(y);
        self
    }

    /// Sets the target rotation in degrees.
    pub fn rotate(mut self, degrees: f32) -> Self {
        self.rotate_degrees = Some(degrees);
        self
    }

    /// Sets the target translation in logical pixels along both axes.
    pub fn translate(mut self, x: f32, y: f32) -> Self {
        self.translate_x = Some(x);
        self.translate_y = Some(y);
        self
    }

    /// Sets the target horizontal translation in logical pixels.
    pub fn translate_x(mut self, x: f32) -> Self {
        self.translate_x = Some(x);
        self
    }

    /// Sets the target vertical translation in logical pixels.
    pub fn translate_y(mut self, y: f32) -> Self {
        self.translate_y = Some(y);
        self
    }

    /// Returns true when this keyframe sets opacity.
    pub fn has_opacity(&self) -> bool {
        self.opacity.is_some()
    }

    /// Returns true when this keyframe sets horizontal or vertical scale.
    pub fn has_scale(&self) -> bool {
        self.scale_x.is_some() || self.scale_y.is_some()
    }

    /// Returns true when this keyframe sets rotation.
    pub fn has_rotation(&self) -> bool {
        self.rotate_degrees.is_some()
    }

    /// Returns true when this keyframe sets horizontal or vertical translation.
    pub fn has_translation(&self) -> bool {
        self.translate_x.is_some() || self.translate_y.is_some()
    }

    /// Returns true when this keyframe sets any transform property.
    pub fn has_transform(&self) -> bool {
        self.has_scale() || self.has_rotation() || self.has_translation()
    }

    /// Returns the number of style properties set by this keyframe.
    pub fn property_count(&self) -> usize {
        [
            self.opacity.is_some(),
            self.scale_x.is_some(),
            self.scale_y.is_some(),
            self.rotate_degrees.is_some(),
            self.translate_x.is_some(),
            self.translate_y.is_some(),
        ]
        .into_iter()
        .filter(|present| *present)
        .count()
    }

    /// Returns true when this keyframe sets no style properties.
    pub fn is_empty(&self) -> bool {
        self.property_count() == 0
    }

    /// Returns a content-safe summary of this styled keyframe.
    pub fn to_text(&self) -> String {
        format!(
            "styled keyframe: properties {}, opacity {}, scale {}, rotation {}, translation {}, empty {}",
            self.property_count(),
            self.has_opacity(),
            self.has_scale(),
            self.has_rotation(),
            self.has_translation(),
            self.is_empty()
        )
    }

    /// Applies this keyframe to a styled element.
    pub fn apply<E: Styled>(self, mut element: E) -> E {
        if let Some(opacity) = self.opacity {
            element = element.opacity(opacity);
        }
        if let (Some(scale_x), Some(scale_y)) = (self.scale_x, self.scale_y) {
            element = element.scale_xy(scale_x, scale_y);
        }
        if let Some(rotate_degrees) = self.rotate_degrees {
            element = element.rotate(rotate_degrees);
        }
        if let Some(translate_x) = self.translate_x {
            element = element.translate_x(crate::px(translate_x));
        }
        if let Some(translate_y) = self.translate_y {
            element = element.translate_y(crate::px(translate_y));
        }
        element
    }

    fn interpolate(self, other: Self, delta: f32) -> Self {
        Self {
            opacity: interpolate_optional(self.opacity, other.opacity, delta),
            scale_x: interpolate_optional(self.scale_x, other.scale_x, delta),
            scale_y: interpolate_optional(self.scale_y, other.scale_y, delta),
            rotate_degrees: interpolate_optional(self.rotate_degrees, other.rotate_degrees, delta),
            translate_x: interpolate_optional(self.translate_x, other.translate_x, delta),
            translate_y: interpolate_optional(self.translate_y, other.translate_y, delta),
        }
    }
}

pub(crate) struct AnimationSample {
    pub delta: f32,
    pub started: bool,
    pub finished: bool,
}

/// Presets for spring-like declarative transitions, each mapping to a tuned duration
/// and an overshoot easing so state-driven style changes feel physical rather than flat.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SpringPreset {
    /// Smooth deceleration with no overshoot.
    Gentle,
    /// Quick settle with a slight overshoot.
    Snappy,
    /// Pronounced, playful bounce.
    Bouncy,
    /// Very fast, tight settle.
    Stiff,
}

impl SpringPreset {
    /// The transition duration for this preset.
    pub fn duration(self) -> Duration {
        match self {
            SpringPreset::Gentle => Duration::from_millis(320),
            SpringPreset::Snappy => Duration::from_millis(260),
            SpringPreset::Bouncy => Duration::from_millis(440),
            SpringPreset::Stiff => Duration::from_millis(180),
        }
    }

    /// The easing curve for this preset.
    pub fn easing(self) -> Easing {
        match self {
            SpringPreset::Gentle => Easing::EaseOutCubic,
            SpringPreset::Snappy => Easing::EaseOutBack(1.4),
            SpringPreset::Bouncy => Easing::EaseOutBack(2.4),
            SpringPreset::Stiff => Easing::EaseOutQuint,
        }
    }
}

fn interpolate_optional(start: Option<f32>, end: Option<f32>, delta: f32) -> Option<f32> {
    match (start, end) {
        (Some(start), Some(end)) => Some(start + (end - start) * delta),
        (Some(value), None) | (None, Some(value)) => Some(value),
        (None, None) => None,
    }
}

fn cubic_bezier(x1: f32, y1: f32, x2: f32, y2: f32, delta: f32) -> f32 {
    let mut low = 0.0;
    let mut high = 1.0;
    let mut t = delta;

    for _ in 0..12 {
        let x = cubic_bezier_axis(x1, x2, t);
        if x < delta {
            low = t;
        } else {
            high = t;
        }
        t = (low + high) / 2.0;
    }

    cubic_bezier_axis(y1, y2, t).clamp(0.0, 1.0)
}

fn cubic_bezier_axis(p1: f32, p2: f32, t: f32) -> f32 {
    let inverse_t = 1.0 - t;
    3.0 * inverse_t * inverse_t * t * p1 + 3.0 * inverse_t * t * t * p2 + t * t * t
}

/// Common easing helpers.
pub mod easing {
    use std::f32::consts::PI;

    /// Returns the input unchanged.
    pub fn linear(delta: f32) -> f32 {
        delta
    }

    /// Applies a quadratic ease-in curve.
    pub fn quadratic(delta: f32) -> f32 {
        delta * delta
    }

    /// Applies a quadratic ease-out curve.
    pub fn ease_out(delta: f32) -> f32 {
        1.0 - (1.0 - delta).powi(2)
    }

    /// Applies a quadratic ease-in-out curve.
    pub fn ease_in_out(delta: f32) -> f32 {
        if delta < 0.5 {
            2.0 * delta * delta
        } else {
            let x = -2.0 * delta + 2.0;
            1.0 - x * x / 2.0
        }
    }

    /// Applies a quintic ease-out curve.
    pub fn ease_out_quint() -> impl Fn(f32) -> f32 {
        move |delta| 1.0 - (1.0 - delta).powi(5)
    }

    /// Plays the provided easing forward and then backward.
    pub fn bounce(easing: impl Fn(f32) -> f32) -> impl Fn(f32) -> f32 {
        move |delta| {
            if delta < 0.5 {
                easing(delta * 2.0)
            } else {
                easing((1.0 - delta) * 2.0)
            }
        }
    }

    /// Produces a soft pulsing alpha curve between two values.
    pub fn pulsating_between(min: f32, max: f32) -> impl Fn(f32) -> f32 {
        let range = max - min;

        move |delta| {
            let t = (delta * 2.0 * PI).sin();
            let breath = (t * t * t + t) / 2.0;
            let normalized_alpha = (breath + 1.0) / 2.0;
            min + normalized_alpha * range
        }
    }
}

#[cfg(test)]
mod easing_variant_tests {
    use super::Easing;

    mod oracle {
        use std::f32::consts::PI;

        pub fn ease_in_cubic(t: f32) -> f32 {
            t * t * t
        }
        pub fn ease_out_cubic(t: f32) -> f32 {
            let t = t - 1.0;
            t * t * t + 1.0
        }
        pub fn ease_in_out_cubic(t: f32) -> f32 {
            if t < 0.5 {
                4.0 * t * t * t
            } else {
                let t = 2.0 * t - 2.0;
                1.0 + t * t * t / 2.0
            }
        }
        pub fn ease_in_quart(t: f32) -> f32 {
            t * t * t * t
        }
        pub fn ease_out_quart(t: f32) -> f32 {
            let t = t - 1.0;
            1.0 - t * t * t * t
        }
        pub fn ease_in_out_quart(t: f32) -> f32 {
            if t < 0.5 {
                8.0 * t * t * t * t
            } else {
                let t = t - 1.0;
                1.0 - 8.0 * t * t * t * t
            }
        }
        pub fn ease_in_quint(t: f32) -> f32 {
            t * t * t * t * t
        }
        pub fn ease_out_quint(t: f32) -> f32 {
            let t = t - 1.0;
            1.0 + t * t * t * t * t
        }
        pub fn ease_in_out_quint(t: f32) -> f32 {
            if t < 0.5 {
                16.0 * t * t * t * t * t
            } else {
                let t = 2.0 * t - 2.0;
                1.0 + t * t * t * t * t / 2.0
            }
        }
        pub fn ease_in_expo(t: f32) -> f32 {
            if t == 0.0 {
                0.0
            } else {
                2_f32.powf(10.0 * t - 10.0)
            }
        }
        pub fn ease_out_expo(t: f32) -> f32 {
            if t >= 1.0 {
                1.0
            } else {
                1.0 - 2_f32.powf(-10.0 * t)
            }
        }
        pub fn ease_in_out_expo(t: f32) -> f32 {
            if t == 0.0 {
                0.0
            } else if t >= 1.0 {
                1.0
            } else if t < 0.5 {
                2_f32.powf(20.0 * t - 10.0) / 2.0
            } else {
                (2.0 - 2_f32.powf(-20.0 * t + 10.0)) / 2.0
            }
        }
        pub fn ease_in_circ(t: f32) -> f32 {
            1.0 - (1.0 - t * t).sqrt()
        }
        pub fn ease_out_circ(t: f32) -> f32 {
            let t = t - 1.0;
            (1.0 - t * t).sqrt()
        }
        pub fn ease_in_out_circ(t: f32) -> f32 {
            if t < 0.5 {
                (1.0 - (1.0 - (2.0 * t).powi(2)).sqrt()) / 2.0
            } else {
                ((1.0 - (-2.0 * t + 2.0).powi(2)).sqrt() + 1.0) / 2.0
            }
        }
        pub fn ease_in_back(t: f32) -> f32 {
            let c1 = 1.70158;
            let c3 = c1 + 1.0;
            (c3 * t * t * t - c1 * t * t).max(0.0)
        }
        pub fn ease_out_back(t: f32) -> f32 {
            if t >= 1.0 {
                return 1.0;
            }
            let c1 = 1.2;
            let c3 = c1 + 1.0;
            let t_adj = t - 1.0;
            (1.0 + c3 * t_adj * t_adj * t_adj + c1 * t_adj * t_adj).clamp(0.0, 1.0)
        }
        pub fn ease_in_out_back(t: f32) -> f32 {
            let c1 = 1.70158;
            let c2 = c1 * 1.525;
            if t < 0.5 {
                ((2.0 * t).powi(2) * ((c2 + 1.0) * 2.0 * t - c2)) / 2.0
            } else {
                (((2.0 * t - 2.0).powi(2) * ((c2 + 1.0) * (t * 2.0 - 2.0) + c2) + 2.0) / 2.0)
                    .clamp(0.0, 1.0)
            }
        }
        pub fn ease_in_elastic(t: f32) -> f32 {
            if t == 0.0 {
                return 0.0;
            }
            if t >= 1.0 {
                return 1.0;
            }
            let c4 = (2.0 * PI) / 3.0;
            (-(2_f32.powf(10.0 * t - 10.0) * ((t * 10.0 - 10.75) * c4).sin())).clamp(0.0, 1.0)
        }
        pub fn ease_out_elastic(t: f32) -> f32 {
            if t == 0.0 {
                return 0.0;
            }
            if t >= 1.0 {
                return 1.0;
            }
            let c4 = (2.0 * PI) / 3.0;
            (2_f32.powf(-10.0 * t) * ((t * 10.0 - 0.75) * c4).sin() + 1.0).clamp(0.0, 1.0)
        }
        pub fn elastic(t: f32) -> f32 {
            if t == 0.0 {
                return 0.0;
            }
            if t >= 1.0 {
                return 1.0;
            }
            let p = 0.3;
            let s = p / 4.0;
            let t_adj = t - 1.0;
            (1.0 + (2_f32.powf(10.0 * t_adj)) * ((t_adj - s) * (2.0 * PI) / p).sin())
                .clamp(0.0, 1.0)
        }
        pub fn steps(n: u32, t: f32) -> f32 {
            let n = n.max(1) as f32;
            (t * n).floor() / n
        }
    }

    const SAMPLES: [f32; 3] = [0.0, 0.5, 1.0];

    fn assert_matches(easing: &Easing, oracle: impl Fn(f32) -> f32) {
        for delta in SAMPLES {
            assert_eq!(easing.sample(delta), oracle(delta), "at delta={delta}");
        }
    }

    #[test]
    fn cubic_variants_match_relocated_math() {
        assert_matches(&Easing::EaseInCubic, oracle::ease_in_cubic);
        assert_matches(&Easing::EaseOutCubic, oracle::ease_out_cubic);
        assert_matches(&Easing::EaseInOutCubic, oracle::ease_in_out_cubic);
    }

    #[test]
    fn quart_variants_match_relocated_math() {
        assert_matches(&Easing::EaseInQuart, oracle::ease_in_quart);
        assert_matches(&Easing::EaseOutQuart, oracle::ease_out_quart);
        assert_matches(&Easing::EaseInOutQuart, oracle::ease_in_out_quart);
    }

    #[test]
    fn quint_variants_match_relocated_math() {
        assert_matches(&Easing::EaseInQuint, oracle::ease_in_quint);
        assert_matches(&Easing::EaseOutQuint, oracle::ease_out_quint);
        assert_matches(&Easing::EaseInOutQuint, oracle::ease_in_out_quint);
    }

    #[test]
    fn expo_variants_match_relocated_math() {
        assert_matches(&Easing::EaseInExpo, oracle::ease_in_expo);
        assert_matches(&Easing::EaseOutExpo, oracle::ease_out_expo);
        assert_matches(&Easing::EaseInOutExpo, oracle::ease_in_out_expo);
    }

    #[test]
    fn circ_variants_match_relocated_math() {
        assert_matches(&Easing::EaseInCirc, oracle::ease_in_circ);
        assert_matches(&Easing::EaseOutCirc, oracle::ease_out_circ);
        assert_matches(&Easing::EaseInOutCirc, oracle::ease_in_out_circ);
    }

    #[test]
    fn back_variants_match_relocated_math() {
        assert_matches(&Easing::EaseInBack(1.70158), oracle::ease_in_back);
        assert_matches(&Easing::EaseOutBack(1.2), oracle::ease_out_back);
        assert_matches(&Easing::EaseInOutBack(1.70158), oracle::ease_in_out_back);
    }

    #[test]
    fn elastic_variants_match_relocated_math() {
        assert_matches(&Easing::EaseInElastic, oracle::ease_in_elastic);
        assert_matches(&Easing::EaseOutElastic, oracle::ease_out_elastic);
        assert_matches(&Easing::Elastic, oracle::elastic);
    }

    #[test]
    fn steps_variant_matches_relocated_math() {
        assert_matches(&Easing::Steps(4), |delta| oracle::steps(4, delta));
        assert_matches(&Easing::Steps(1), |delta| oracle::steps(1, delta));
    }

    #[test]
    fn quad_aliases_remain_quadratic() {
        assert_eq!(Easing::EaseIn.sample(0.5), 0.25);
        assert_eq!(Easing::EaseOut.sample(0.5), 0.75);
    }
}

#[cfg(test)]
mod tests {
    use super::{Animation, AnimationSequence, Easing, Repeat, keyframes};
    use crate::animation::StyledKeyframe;
    use std::time::Duration;

    #[test]
    fn keyframe_translate_interpolates() {
        let frames = keyframes()
            .at(0.0, |frame| frame.translate(0.0, 0.0))
            .at(1.0, |frame| frame.translate(100.0, 40.0));

        let midpoint = frames.sample(0.5);
        assert_eq!(midpoint.translate_x, Some(50.0));
        assert_eq!(midpoint.translate_y, Some(20.0));
    }

    #[test]
    fn stagger_offsets_delay_by_index() {
        let step = Duration::from_millis(50);
        let staggered = Animation::new(Duration::from_millis(200)).stagger(3, step);
        assert_eq!(staggered.delay, Duration::from_millis(150));
    }

    #[test]
    fn spring_presets_map_to_tuned_easings() {
        use super::{Easing, SpringPreset};

        assert_eq!(SpringPreset::Snappy.duration(), Duration::from_millis(260));
        assert!(matches!(
            SpringPreset::Snappy.easing(),
            Easing::EaseOutBack(_)
        ));
        assert!(matches!(
            SpringPreset::Gentle.easing(),
            Easing::EaseOutCubic
        ));
        assert!(matches!(SpringPreset::Stiff.easing(), Easing::EaseOutQuint));
    }

    #[test]
    fn animation_sequence_offsets_the_next_step() {
        let sequence = AnimationSequence::new()
            .then(Animation::new(Duration::from_millis(200)))
            .then(Animation::new(Duration::from_millis(300)))
            .with_overlap(Duration::from_millis(100));

        let animations = sequence.into_animations();
        assert_eq!(animations.len(), 2);
        assert_eq!(animations[0].scheduled_end(), Duration::from_millis(200));
        assert_eq!(animations[1].scheduled_end(), Duration::from_millis(400));
    }

    #[test]
    fn keyframes_interpolate_between_styles() {
        let frames = keyframes()
            .at(0.0, |frame| frame.scale(1.0).opacity(1.0))
            .at(1.0, |frame| frame.scale(1.2).opacity(0.5));

        let sample = frames.sample(0.5);
        assert_eq!(sample, StyledKeyframe::default().scale(1.1).opacity(0.75));
    }

    #[test]
    fn counted_animations_finish_after_the_requested_cycles() {
        let animation = Animation::new(Duration::from_millis(100)).repeat(Repeat::Count(2));

        assert!(!animation.sample(Duration::from_millis(150)).finished);
        assert!(animation.sample(Duration::from_millis(250)).finished);
    }

    #[test]
    fn animation_summaries_expose_timeline_shape() {
        let animation = Animation::new(Duration::from_millis(240))
            .delay(Duration::from_millis(60))
            .easing(Easing::CubicBezier(0.25, 0.1, 0.25, 1.0))
            .repeat(Repeat::Count(3));

        assert_eq!(animation.duration(), Duration::from_millis(240));
        assert_eq!(animation.delay_duration(), Duration::from_millis(60));
        assert!(animation.has_delay());
        assert_eq!(animation.easing_curve().to_text(), "cubic-bezier");
        assert_eq!(animation.repeat_mode(), Repeat::Count(3));
        assert_eq!(animation.repeat_mode().count(), Some(3));
        assert!(!animation.repeats_forever());
        assert_eq!(animation.scheduled_duration(), Duration::from_millis(780));
        assert_eq!(
            animation.to_text(),
            "animation: duration_ms 240, delay_ms 60, easing cubic-bezier, repeat count, scheduled_ms 780, forever false"
        );
        assert!(!animation.to_text().contains("0.25"));
        assert!(!animation.to_text().contains("0.1"));

        let custom = Animation::new(Duration::from_millis(1)).with_easing(|delta| delta);
        assert!(custom.easing_curve().is_custom());
        assert!(Repeat::Forever.is_forever());
        assert_eq!(Repeat::Forever.to_text(), "forever");
    }

    #[test]
    fn sequence_and_keyframe_summaries_expose_counts_not_values() {
        let sequence = AnimationSequence::new()
            .then(Animation::new(Duration::from_millis(100)))
            .then(Animation::new(Duration::from_millis(200)).repeat_forever());

        assert_eq!(sequence.len(), 2);
        assert!(!sequence.is_empty());
        assert!(sequence.has_infinite_animation());
        assert_eq!(
            sequence.to_text(),
            "animation sequence: animations 2, scheduled_ms 300, infinite true, empty false"
        );

        let keyframe = StyledKeyframe::default()
            .opacity(0.42)
            .scale_xy(1.25, 0.75)
            .rotate(37.0)
            .translate(123.0, 456.0);

        assert_eq!(keyframe.property_count(), 6);
        assert!(keyframe.has_opacity());
        assert!(keyframe.has_scale());
        assert!(keyframe.has_rotation());
        assert!(keyframe.has_translation());
        assert!(!keyframe.is_empty());
        assert_eq!(
            keyframe.to_text(),
            "styled keyframe: properties 6, opacity true, scale true, rotation true, translation true, empty false"
        );
        assert!(!keyframe.to_text().contains("123"));
        assert!(!keyframe.to_text().contains("0.42"));

        let frames = keyframes()
            .at(0.0, |_| keyframe)
            .at(1.0, |frame| frame.opacity(0.0));
        assert_eq!(frames.len(), 2);
        assert!(!frames.is_empty());
        assert_eq!(frames.opacity_frame_count(), 2);
        assert_eq!(frames.transform_frame_count(), 1);
        assert_eq!(
            frames.to_text(),
            "keyframes: frames 2, opacity_frames 2, transform_frames 1, empty false"
        );
        assert!(!frames.to_text().contains("456"));
    }
}

#[cfg(test)]
mod media_keyframe_tests {
    use super::*;

    #[test]
    fn empty_track_returns_default() {
        let track = KeyframeTrack::new();
        assert_eq!(track.sample(1.0, 42.0), 42.0);
        assert!(track.is_empty());
    }

    #[test]
    fn single_key_is_constant() {
        let track = KeyframeTrack::new().with_key(1.0, 5.0, KeyframeInterpolation::Hold);
        assert_eq!(track.sample(0.0, 0.0), 5.0);
        assert_eq!(track.sample(2.0, 0.0), 5.0);
    }

    #[test]
    fn linear_interpolates_between_keys() {
        let track = KeyframeTrack::new()
            .with_key(0.0, 0.0, KeyframeInterpolation::Eased(Easing::Linear))
            .with_key(1.0, 10.0, KeyframeInterpolation::Hold);
        assert!((track.sample(0.5, 0.0) - 5.0).abs() < 1e-5);
        assert!((track.sample(0.25, 0.0) - 2.5).abs() < 1e-5);
    }

    #[test]
    fn hold_steps_until_next_key() {
        let track = KeyframeTrack::new()
            .with_key(0.0, 1.0, KeyframeInterpolation::Hold)
            .with_key(1.0, 9.0, KeyframeInterpolation::Hold);
        assert_eq!(track.sample(0.5, 0.0), 1.0);
        assert_eq!(track.sample(0.99, 0.0), 1.0);
        assert_eq!(track.sample(1.0, 0.0), 9.0);
    }

    #[test]
    fn easing_differs_from_linear() {
        let eased = KeyframeTrack::new()
            .with_key(0.0, 0.0, KeyframeInterpolation::Eased(Easing::EaseIn))
            .with_key(1.0, 10.0, KeyframeInterpolation::Hold);
        assert!(eased.sample(0.5, 0.0) < 5.0);
    }

    #[test]
    fn clamps_outside_range() {
        let track = KeyframeTrack::new()
            .with_key(1.0, 2.0, KeyframeInterpolation::Eased(Easing::Linear))
            .with_key(3.0, 8.0, KeyframeInterpolation::Hold);
        assert_eq!(track.sample(-5.0, 0.0), 2.0);
        assert_eq!(track.sample(100.0, 0.0), 8.0);
    }

    #[test]
    fn out_of_order_insertion_stays_sorted() {
        let mut track = KeyframeTrack::new();
        track.insert(MediaKeyframe {
            time: 2.0,
            value: 20.0,
            interpolation: KeyframeInterpolation::Hold,
        });
        track.insert(MediaKeyframe {
            time: 0.0,
            value: 0.0,
            interpolation: KeyframeInterpolation::Eased(Easing::Linear),
        });
        track.insert(MediaKeyframe {
            time: 1.0,
            value: 10.0,
            interpolation: KeyframeInterpolation::Eased(Easing::Linear),
        });
        assert!((track.sample(0.5, 0.0) - 5.0).abs() < 1e-5);
        assert!((track.sample(1.5, 0.0) - 15.0).abs() < 1e-5);
        assert_eq!(track.len(), 3);
    }

    #[test]
    fn media_keyframe_summaries_do_not_leak_values() {
        let key = MediaKeyframe {
            time: 12.5,
            value: 99.0,
            interpolation: KeyframeInterpolation::Eased(Easing::EaseOutBack(1.7)),
        };

        assert_eq!(key.interpolation.to_text(), "eased");
        assert_eq!(
            key.to_text(),
            "media keyframe: interpolation eased, finite_time true, finite_value true"
        );
        assert!(!key.to_text().contains("12.5"));
        assert!(!key.to_text().contains("99"));

        let track = KeyframeTrack::new()
            .with_key(0.0, 0.0, KeyframeInterpolation::Hold)
            .with_key(1.0, 10.0, KeyframeInterpolation::Eased(Easing::Linear))
            .with_key(2.0, 20.0, KeyframeInterpolation::Eased(Easing::Steps(4)));

        assert_eq!(track.hold_count(), 1);
        assert_eq!(track.eased_count(), 2);
        assert!(track.is_finite());
        assert_eq!(
            track.to_text(),
            "keyframe track: keys 3, hold 1, eased 2, finite true, empty false"
        );
        assert!(!track.to_text().contains("20"));
        assert!(!track.to_text().contains("10"));
        assert_eq!(Easing::Steps(4).to_text(), "steps");
        assert_eq!(Easing::EaseOutBack(1.7).to_text(), "ease-out-back");
    }
}
