use crate::{
    AnyWindowHandle, Bounds, Decorations, DevicePixels, DispatchEventResult, DisplayId, GpuSpecs,
    HeadlessAtlas, KeyDownEvent, NativeViewId, Pixels, Platform, PlatformAtlas, PlatformDisplay,
    PlatformHeadlessRenderer, PlatformInput, PlatformInputHandler, PlatformWindow, Point,
    PromptButton, RequestFrameOptions, Scene, Size, TestDisplay, TestPlatform,
    TextInputConfiguration, TextInputStateChange, WindowAppearance, WindowBackgroundAppearance,
    WindowBounds, WindowControlArea, WindowInsets, WindowParams, WindowVisibility,
};
use gpui_util::ResultExt as _;
#[cfg(any(test, feature = "test-support"))]
use image::RgbaImage;
use parking_lot::Mutex;
use raw_window_handle::{HasDisplayHandle, HasWindowHandle};
use std::{
    cell::Cell,
    path::PathBuf,
    rc::{Rc, Weak},
    sync::{self, Arc},
};

pub(crate) struct TestWindowState {
    pub(crate) bounds: Bounds<Pixels>,
    pub(crate) handle: AnyWindowHandle,
    display: Rc<dyn PlatformDisplay>,
    pub(crate) title: Option<String>,
    pub(crate) edited: bool,
    pub(crate) document_path: Option<std::path::PathBuf>,
    platform: Weak<TestPlatform>,
    // TODO: Replace with `Rc`
    sprite_atlas: Arc<dyn PlatformAtlas>,
    renderer: Option<Box<dyn PlatformHeadlessRenderer>>,
    pub(crate) should_close_handler: Option<Box<dyn FnMut() -> bool>>,
    close_callback: Option<Box<dyn FnOnce()>>,
    hit_test_window_control_callback: Option<Box<dyn FnMut() -> Option<WindowControlArea>>>,
    attached_native_views: Rc<Cell<usize>>,
    focused_native_view: Option<NativeViewId>,
    hit_test_native_view_callback: Option<Box<dyn FnMut(Point<Pixels>) -> Option<NativeViewId>>>,
    native_view_focused_callback: Option<Box<dyn FnMut(NativeViewId)>>,
    key_down_before_native_view_callback: Option<Box<dyn FnMut(KeyDownEvent) -> bool>>,
    input_callback: Option<Box<dyn FnMut(PlatformInput) -> DispatchEventResult>>,
    active_status_change_callback: Option<Box<dyn FnMut(bool)>>,
    visibility: WindowVisibility,
    visibility_callback: Option<Box<dyn FnMut(WindowVisibility)>>,
    hover_status_change_callback: Option<Box<dyn FnMut(bool)>>,
    resize_callback: Option<Box<dyn FnMut(Size<Pixels>, f32)>>,
    visual_viewport: Option<Bounds<Pixels>>,
    visual_viewport_callback: Option<Box<dyn FnMut()>>,
    insets: WindowInsets,
    insets_callback: Option<Box<dyn FnMut(WindowInsets)>>,
    virtual_keyboard_requests: usize,
    virtual_keyboard_dismissals: usize,
    moved_callback: Option<Box<dyn FnMut()>>,
    display_changed_callback: Option<Box<dyn FnMut()>>,
    appearance_change_callback: Option<Box<dyn FnMut()>>,
    request_frame_callback: Option<Box<dyn FnMut(RequestFrameOptions)>>,
    frame_wake_count: Rc<Cell<usize>>,
    frame_scheduled: bool,
    frame_callback_pending: bool,
    input_handler: Option<PlatformInputHandler>,
    text_input_configurations: Vec<TextInputConfiguration>,
    text_input_state_changes: Vec<TextInputStateChange>,
    is_fullscreen: bool,
    scale_factor: f32,
    appearance: WindowAppearance,
    decorations: Decorations,
    external_drag_files: Vec<(PathBuf, bool)>,
    start_external_drag_result: bool,
}

#[derive(Clone)]
pub struct TestWindow(pub(crate) Rc<Mutex<TestWindowState>>);

// Test windows are not backed by a real platform window, so there is no raw
// handle to report; `NotSupported` is `raw_window_handle`'s variant for exactly this.
impl HasWindowHandle for TestWindow {
    fn window_handle(
        &self,
    ) -> Result<raw_window_handle::WindowHandle<'_>, raw_window_handle::HandleError> {
        Err(raw_window_handle::HandleError::NotSupported)
    }
}

impl HasDisplayHandle for TestWindow {
    fn display_handle(
        &self,
    ) -> Result<raw_window_handle::DisplayHandle<'_>, raw_window_handle::HandleError> {
        Err(raw_window_handle::HandleError::NotSupported)
    }
}

impl TestWindow {
    pub(crate) fn new(
        handle: AnyWindowHandle,
        params: WindowParams,
        platform: Weak<TestPlatform>,
        display: Rc<dyn PlatformDisplay>,
        renderer: Option<Box<dyn PlatformHeadlessRenderer>>,
    ) -> Self {
        let sprite_atlas: Arc<dyn PlatformAtlas> = match &renderer {
            Some(r) => r.sprite_atlas(),
            None => Arc::new(HeadlessAtlas::default()),
        };
        Self(Rc::new(Mutex::new(TestWindowState {
            bounds: params.bounds,
            display,
            platform,
            handle,
            sprite_atlas,
            renderer,
            title: Default::default(),
            edited: false,
            document_path: None,
            should_close_handler: None,
            close_callback: None,
            hit_test_window_control_callback: None,
            input_callback: None,
            active_status_change_callback: None,
            visibility: WindowVisibility::Visible,
            visibility_callback: None,
            hover_status_change_callback: None,
            resize_callback: None,
            visual_viewport: None,
            visual_viewport_callback: None,
            insets: WindowInsets::default(),
            insets_callback: None,
            virtual_keyboard_requests: 0,
            virtual_keyboard_dismissals: 0,
            moved_callback: None,
            display_changed_callback: None,
            appearance_change_callback: None,
            attached_native_views: Rc::new(Cell::new(0)),
            focused_native_view: None,
            hit_test_native_view_callback: None,
            native_view_focused_callback: None,
            key_down_before_native_view_callback: None,
            request_frame_callback: None,
            frame_wake_count: Rc::new(Cell::new(0)),
            frame_scheduled: false,
            frame_callback_pending: false,
            input_handler: None,
            text_input_configurations: Vec::new(),
            text_input_state_changes: Vec::new(),
            is_fullscreen: false,
            // Preserve the test platform's historical 2x default.
            scale_factor: 2.0,
            appearance: WindowAppearance::Light,
            decorations: Decorations::default(),
            external_drag_files: Vec::new(),
            start_external_drag_result: false,
        })))
    }
    pub fn simulate_close(&self) {
        let callback = self.0.lock().close_callback.take();
        if let Some(callback) = callback {
            callback();
        }
    }

    pub fn simulate_scheduled_frame(&self) -> bool {
        let callback = {
            let mut state = self.0.lock();
            if !std::mem::take(&mut state.frame_scheduled) {
                return false;
            }
            state.frame_callback_pending = false;
            state.request_frame_callback.take()
        };
        let Some(mut callback) = callback else {
            self.0.lock().frame_scheduled = true;
            return false;
        };

        callback(RequestFrameOptions::default());
        self.0.lock().request_frame_callback = Some(callback);
        true
    }

    pub fn frame_scheduled(&self) -> bool {
        self.0.lock().frame_scheduled
    }

    pub fn simulate_visibility_change(&self, visibility: WindowVisibility) {
        let callback = {
            let mut state = self.0.lock();
            state.visibility = visibility;
            state.visibility_callback.take()
        };
        if let Some(mut callback) = callback {
            callback(visibility);
            self.0.lock().visibility_callback = Some(callback);
        }
    }

    /// Moves the window to the display with the given ID.
    pub fn simulate_move_to_display(&self, display_id: DisplayId) {
        let callback = {
            let mut state = self.0.lock();
            state.display = Rc::new(TestDisplay::with_id(display_id));
            state.display_changed_callback.take()
        };
        if let Some(mut callback) = callback {
            callback();
            self.0.lock().display_changed_callback = Some(callback);
        }
    }

    pub fn simulate_visual_viewport_change(&self, bounds: Bounds<Pixels>) {
        let callback = {
            let mut state = self.0.lock();
            state.visual_viewport = Some(bounds);
            state.visual_viewport_callback.take()
        };
        if let Some(mut callback) = callback {
            callback();
            self.0.lock().visual_viewport_callback = Some(callback);
        }
    }

    pub fn simulate_insets_change(&self, insets: WindowInsets) {
        let callback = {
            let mut state = self.0.lock();
            state.insets = insets.clone();
            state.insets_callback.take()
        };
        if let Some(mut callback) = callback {
            callback(insets);
            self.0.lock().insets_callback = Some(callback);
        }
    }

    pub fn virtual_keyboard_requests(&self) -> usize {
        self.0.lock().virtual_keyboard_requests
    }

    pub fn virtual_keyboard_dismissals(&self) -> usize {
        self.0.lock().virtual_keyboard_dismissals
    }

    /// Every [`TextInputConfiguration`] forwarded to this window, in order.
    pub fn text_input_configurations(&self) -> Vec<TextInputConfiguration> {
        self.0.lock().text_input_configurations.clone()
    }

    pub fn text_input_state_changes(&self) -> Vec<TextInputStateChange> {
        self.0.lock().text_input_state_changes.clone()
    }

    pub fn simulate_resize(&mut self, size: Size<Pixels>) {
        let scale_factor = self.scale_factor();
        let mut lock = self.0.lock();
        // Always update bounds, even if no callback is registered
        lock.bounds.size = size;
        let Some(mut callback) = lock.resize_callback.take() else {
            return;
        };
        drop(lock);
        callback(size, scale_factor);
        self.0.lock().resize_callback = Some(callback);
    }

    /// Simulates a display scale change through the resize callback, preserving logical bounds.
    pub fn simulate_scale_factor_change(&mut self, scale_factor: f32) {
        let size = {
            let mut lock = self.0.lock();
            lock.scale_factor = scale_factor;
            lock.bounds.size
        };
        self.simulate_resize(size);
    }

    /// How many native views are attached to the window.
    pub fn attached_native_view_count(&self) -> usize {
        self.0.lock().attached_native_views.get()
    }

    /// The native view the window last gave keyboard input to.
    pub fn focused_native_view(&self) -> Option<NativeViewId> {
        self.0.lock().focused_native_view
    }

    /// Asks the window which native view a mouse event at `position` reaches.
    pub fn hit_test_native_view(&self, position: Point<Pixels>) -> Option<NativeViewId> {
        let mut callback = self.0.lock().hit_test_native_view_callback.take()?;
        let id = callback(position);
        self.0.lock().hit_test_native_view_callback = Some(callback);
        id
    }

    /// Acts as if the user pressed a key while a native view had keyboard input,
    /// and returns whether the window used the key before the view saw it.
    pub fn simulate_key_down_before_native_view(&self, event: KeyDownEvent) -> bool {
        let Some(mut callback) = self.0.lock().key_down_before_native_view_callback.take() else {
            return false;
        };
        let handled = callback(event);
        self.0.lock().key_down_before_native_view_callback = Some(callback);
        handled
    }

    /// Acts as if the user moved keyboard input to a native view through the platform.
    pub fn simulate_native_view_focused(&self, id: NativeViewId) {
        let mut lock = self.0.lock();
        lock.focused_native_view = Some(id);
        let Some(mut callback) = lock.native_view_focused_callback.take() else {
            return;
        };
        drop(lock);
        callback(id);
        self.0.lock().native_view_focused_callback = Some(callback);
    }

    pub(crate) fn simulate_active_status_change(&self, active: bool) {
        let mut lock = self.0.lock();
        let Some(mut callback) = lock.active_status_change_callback.take() else {
            return;
        };
        drop(lock);
        callback(active);
        self.0.lock().active_status_change_callback = Some(callback);
    }

    pub fn simulate_appearance_change(&self, appearance: WindowAppearance) {
        let mut lock = self.0.lock();
        lock.appearance = appearance;
        let Some(mut callback) = lock.appearance_change_callback.take() else {
            return;
        };
        drop(lock);
        callback();
        self.0.lock().appearance_change_callback = Some(callback);
    }

    pub fn simulate_decorations_change(&self, decorations: Decorations) {
        let mut lock = self.0.lock();
        lock.decorations = decorations;
        let Some(mut callback) = lock.appearance_change_callback.take() else {
            return;
        };
        drop(lock);
        callback();
        self.0.lock().appearance_change_callback = Some(callback);
    }

    /// Returns how many times this window's frame waker has been invoked.
    pub fn frame_wake_count(&self) -> usize {
        self.0.lock().frame_wake_count.get()
    }

    /// Delivers a frame request to the window, as the platform's frame source
    /// would.
    pub fn simulate_frame_request(&self, options: RequestFrameOptions) {
        let mut lock = self.0.lock();
        let Some(mut callback) = lock.request_frame_callback.take() else {
            return;
        };
        drop(lock);
        callback(options);
        self.0.lock().request_frame_callback = Some(callback);
    }

    pub fn simulate_input(&mut self, event: PlatformInput) -> bool {
        let mut lock = self.0.lock();
        let Some(mut callback) = lock.input_callback.take() else {
            return false;
        };
        drop(lock);
        let result = callback(event);
        self.0.lock().input_callback = Some(callback);
        !result.propagate
    }

    pub fn external_drag_files(&self) -> Vec<(PathBuf, bool)> {
        self.0.lock().external_drag_files.clone()
    }

    pub fn set_start_external_drag_result(&self, result: bool) {
        self.0.lock().start_external_drag_result = result;
    }
}

impl PlatformWindow for TestWindow {
    fn visual_viewport_bounds(&self) -> Bounds<Pixels> {
        let state = self.0.lock();
        state
            .visual_viewport
            .unwrap_or_else(|| Bounds::new(Point::default(), state.bounds.size))
    }

    fn on_visual_viewport_changed(&self, callback: Box<dyn FnMut()>) {
        self.0.lock().visual_viewport_callback = Some(callback);
    }

    fn insets(&self) -> WindowInsets {
        self.0.lock().insets.clone()
    }

    fn on_insets_changed(&self, callback: Box<dyn FnMut(WindowInsets)>) {
        self.0.lock().insets_callback = Some(callback);
    }

    fn show_soft_keyboard(&self) {
        self.0.lock().virtual_keyboard_requests += 1;
    }

    fn hide_soft_keyboard(&self) {
        self.0.lock().virtual_keyboard_dismissals += 1;
    }

    fn bounds(&self) -> Bounds<Pixels> {
        self.0.lock().bounds
    }

    fn window_bounds(&self) -> WindowBounds {
        WindowBounds::Windowed(self.bounds())
    }

    fn is_maximized(&self) -> bool {
        false
    }

    fn content_size(&self) -> Size<Pixels> {
        self.bounds().size
    }

    fn resize(&mut self, size: Size<Pixels>) {
        let mut lock = self.0.lock();
        lock.bounds.size = size;
    }

    fn scale_factor(&self) -> f32 {
        self.0.lock().scale_factor
    }

    fn appearance(&self) -> WindowAppearance {
        self.0.lock().appearance
    }

    fn display(&self) -> Option<std::rc::Rc<dyn crate::PlatformDisplay>> {
        Some(self.0.lock().display.clone())
    }

    fn mouse_position(&self) -> Point<Pixels> {
        Point::default()
    }

    fn modifiers(&self) -> crate::Modifiers {
        crate::Modifiers::default()
    }

    fn capslock(&self) -> crate::Capslock {
        crate::Capslock::default()
    }

    fn set_input_handler(&mut self, input_handler: PlatformInputHandler) {
        self.0.lock().input_handler = Some(input_handler);
    }

    fn take_input_handler(&mut self) -> Option<PlatformInputHandler> {
        self.0.lock().input_handler.take()
    }

    fn set_text_input_configuration(&mut self, configuration: TextInputConfiguration) {
        self.0.lock().text_input_configurations.push(configuration);
    }

    fn text_input_state_changed(&self, change: TextInputStateChange) {
        self.0.lock().text_input_state_changes.push(change);
    }

    fn prompt(
        &self,
        _level: crate::PromptLevel,
        msg: &str,
        detail: Option<&str>,
        answers: &[PromptButton],
    ) -> Option<futures::channel::oneshot::Receiver<usize>> {
        Some(
            self.0
                .lock()
                .platform
                .upgrade()
                .expect("platform dropped")
                .prompt(msg, detail, answers),
        )
    }

    fn activate(&self) {
        self.0
            .lock()
            .platform
            .upgrade()
            .unwrap()
            .set_active_window(Some(self.clone()))
    }

    fn is_active(&self) -> bool {
        false
    }

    fn visibility(&self) -> WindowVisibility {
        self.0.lock().visibility
    }

    fn is_hovered(&self) -> bool {
        false
    }

    fn background_appearance(&self) -> WindowBackgroundAppearance {
        WindowBackgroundAppearance::Opaque
    }

    fn is_subpixel_rendering_supported(&self) -> bool {
        false
    }

    fn set_title(&mut self, title: &str) {
        self.0.lock().title = Some(title.to_owned());
    }

    fn set_app_id(&mut self, _app_id: &str) {}

    fn set_background_appearance(&self, _background: WindowBackgroundAppearance) {}

    fn set_edited(&mut self, edited: bool) {
        self.0.lock().edited = edited;
    }

    fn set_document_path(&self, path: Option<&std::path::Path>) {
        self.0.lock().document_path = path.map(|p| p.to_path_buf());
    }

    fn show_character_palette(&self) {
        unimplemented!()
    }

    fn minimize(&self) {
        unimplemented!()
    }

    fn zoom(&self) {
        unimplemented!()
    }

    fn toggle_fullscreen(&self) {
        let platform = {
            let mut lock = self.0.lock();
            lock.is_fullscreen = !lock.is_fullscreen;
            lock.platform.upgrade()
        };
        if let Some(platform) = platform {
            let mut window = self.clone();
            platform
                .foreground_executor()
                .spawn(async move {
                    let size = window.0.lock().bounds.size;
                    window.simulate_resize(size);
                })
                .detach();
        }
    }

    fn is_fullscreen(&self) -> bool {
        self.0.lock().is_fullscreen
    }

    fn frame_waker(&self) -> Option<Rc<dyn Fn()>> {
        // Tests can inspect wakes without delivering a frame synchronously.
        let frame_wake_count = self.0.lock().frame_wake_count.clone();
        #[cfg(feature = "bench-support")]
        let window = Rc::downgrade(&self.0);
        Some(Rc::new(move || {
            frame_wake_count.set(frame_wake_count.get() + 1);
            #[cfg(feature = "bench-support")]
            if let Some(window) = window.upgrade() {
                TestWindow(window).schedule_frame();
            }
        }))
    }

    fn on_request_frame(&self, callback: Box<dyn FnMut(RequestFrameOptions)>) {
        self.0.lock().request_frame_callback = Some(callback);
    }

    fn schedule_frame(&self) {
        let mut state = self.0.lock();
        if !state.frame_callback_pending {
            state.frame_scheduled = true;
        }
    }

    fn on_input(&self, callback: Box<dyn FnMut(crate::PlatformInput) -> DispatchEventResult>) {
        self.0.lock().input_callback = Some(callback)
    }

    fn on_active_status_change(&self, callback: Box<dyn FnMut(bool)>) {
        self.0.lock().active_status_change_callback = Some(callback)
    }

    fn on_visibility_change(&self, callback: Box<dyn FnMut(WindowVisibility)>) {
        self.0.lock().visibility_callback = Some(callback);
    }

    fn on_hover_status_change(&self, callback: Box<dyn FnMut(bool)>) {
        self.0.lock().hover_status_change_callback = Some(callback)
    }

    fn on_resize(&self, callback: Box<dyn FnMut(Size<Pixels>, f32)>) {
        self.0.lock().resize_callback = Some(callback)
    }

    fn on_moved(&self, callback: Box<dyn FnMut()>) {
        self.0.lock().moved_callback = Some(callback)
    }

    fn on_display_changed(&self, callback: Box<dyn FnMut()>) {
        self.0.lock().display_changed_callback = Some(callback)
    }

    fn on_should_close(&self, callback: Box<dyn FnMut() -> bool>) {
        self.0.lock().should_close_handler = Some(callback);
    }

    fn on_close(&self, callback: Box<dyn FnOnce()>) {
        self.0.lock().close_callback = Some(callback);
    }

    fn on_hit_test_window_control(&self, callback: Box<dyn FnMut() -> Option<WindowControlArea>>) {
        self.0.lock().hit_test_window_control_callback = Some(callback);
    }

    /// Counts the view as attached without ever reading `_view`, so tests may
    /// pass a dangling pointer.
    unsafe fn attach_native_view(
        &self,
        _id: NativeViewId,
        _view: std::ptr::NonNull<std::ffi::c_void>,
    ) -> Option<Box<dyn std::any::Any>> {
        struct Attachment(Rc<Cell<usize>>);

        impl Drop for Attachment {
            fn drop(&mut self) {
                self.0.set(self.0.get() - 1);
            }
        }

        let attached_native_views = self.0.lock().attached_native_views.clone();
        attached_native_views.set(attached_native_views.get() + 1);
        Some(Box::new(Attachment(attached_native_views)))
    }

    fn set_focused_native_view(&self, id: Option<NativeViewId>) {
        self.0.lock().focused_native_view = id;
    }

    fn on_key_down_before_native_view(&self, callback: Box<dyn FnMut(KeyDownEvent) -> bool>) {
        self.0.lock().key_down_before_native_view_callback = Some(callback);
    }

    fn on_hit_test_native_view(
        &self,
        callback: Box<dyn FnMut(Point<Pixels>) -> Option<NativeViewId>>,
    ) {
        self.0.lock().hit_test_native_view_callback = Some(callback);
    }

    fn on_native_view_focused(&self, callback: Box<dyn FnMut(NativeViewId)>) {
        self.0.lock().native_view_focused_callback = Some(callback);
    }

    fn on_appearance_changed(&self, callback: Box<dyn FnMut()>) {
        self.0.lock().appearance_change_callback = Some(callback);
    }

    fn draw(&self, scene: &Scene) {
        let scale_factor = self.scale_factor();
        let mut state = self.0.lock();
        state.frame_callback_pending = true;
        state.frame_scheduled = true;
        let device_size: Size<DevicePixels> = state.bounds.size.to_device_pixels(scale_factor);
        if let Some(renderer) = &mut state.renderer {
            renderer.render_scene(scene, device_size).warn_on_err();
        }
    }

    fn sprite_atlas(&self) -> sync::Arc<dyn crate::PlatformAtlas> {
        self.0.lock().sprite_atlas.clone()
    }

    #[cfg(any(test, feature = "test-support"))]
    fn render_to_image(&self, scene: &Scene) -> anyhow::Result<RgbaImage> {
        let scale_factor = self.scale_factor();
        let mut state = self.0.lock();
        let size = state.bounds.size;
        if let Some(renderer) = &mut state.renderer {
            let device_size: Size<DevicePixels> = size.to_device_pixels(scale_factor);
            renderer.render_scene_to_image(scene, device_size)
        } else {
            anyhow::bail!("render_to_image not available: no HeadlessRenderer configured")
        }
    }

    fn as_test(&mut self) -> Option<&mut TestWindow> {
        Some(self)
    }

    #[cfg(target_os = "windows")]
    fn get_raw_handle(&self) -> windows::Win32::Foundation::HWND {
        unimplemented!()
    }

    fn show_window_menu(&self, _position: Point<Pixels>) {
        unimplemented!()
    }

    fn start_window_move(&self) {
        unimplemented!()
    }

    fn can_start_external_drag(&self) -> bool {
        true
    }

    fn start_external_drag(&self, payload: &crate::ExternalDragPayload) -> bool {
        let mut state = self.0.lock();
        match payload {
            crate::ExternalDragPayload::Files(paths) => {
                state.external_drag_files.extend_from_slice(paths.entries());
            }
        }
        state.start_external_drag_result
    }

    fn update_ime_position(&self, _bounds: Bounds<Pixels>) {}

    fn gpu_specs(&self) -> Option<GpuSpecs> {
        None
    }

    fn window_decorations(&self) -> Decorations {
        self.0.lock().decorations
    }
}
