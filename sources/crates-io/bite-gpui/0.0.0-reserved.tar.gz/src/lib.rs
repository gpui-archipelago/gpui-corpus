//! A name reservation, not a library.
//!
//! crates.io validates that every dependency name in a manifest exists before it
//! accepts an upload, dev-dependencies included. Six crates in this release name
//! `bite-gpui` from their `[dev-dependencies]`, and `bite-gpui` cannot be
//! published before them, because its own dependencies include three of them.
//! Reserving the name breaks that deadlock once.
//!
//! The real facade is `bite-gpui` 1.20.203.
